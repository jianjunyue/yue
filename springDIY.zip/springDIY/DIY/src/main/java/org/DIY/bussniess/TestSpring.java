package org.DIY.bussniess;

import org.DIY.ioc.framework.ApplicationConext;

public class TestSpring {
    public static void main(String[] args) {
        //实例化上下文
        ApplicationConext context = new ApplicationConext("/applicationContext.xml");
        //根据 id 从容器中获取 Computer 的 bean 对象
        Computer computer = context.getBean("computer");
        //运行主机
        computer.run();
    }
}
