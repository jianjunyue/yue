package org.DIY.bussniess;

public interface IUsb {
	
	public void useUSB();

}
