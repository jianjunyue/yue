package org.bimarket.news;

import java.text.ParseException;

import org.bimarket.base.util.DateUtil;

public class Test {

	public static void main(String[] args) {
		System.out.println(getTime("2018-03-28 12"));

	}

	public static String getTime(String time) {
		try {
			if (time == null || time.length() == 0) {
				time = DateUtil.getDateTimeFormat();
			} else if (time.length() == 10) {
				time = time + " 00:00:00";
			} else if (time.length() == 13) {
				time = time + ":00:00";
			} else if (time.length() == 16) {
				time = time + ":00";
			}

			time = DateUtil.getFromString(time);
		} catch (ParseException e) {
			time = DateUtil.getDateTimeFormat();
			e.printStackTrace();
		}
		return time;
	}
}
