package org.bimarket.news.core.model;

public class DataInfo {

	private String source;
	private String source_url;//列表URL
	
	private String  regUrlOuter;//外围匹配
	
	private String regUrl;
	private String regLog;
	private String regTitle;
	private String regContent;
	private String regTime;

	private String titleReflectFunName;
	private String urlReflectFunName; 
	private String logReflectFunName;
	private String contentReflectFunName;
	private String timeReflectFunName;
 
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getSource_url() {
		return source_url;
	}
	public void setSource_url(String source_url) {
		this.source_url = source_url;
	}
	public String getRegUrl() {
		return regUrl;
	}
	public void setRegUrl(String regUrl) {
		this.regUrl = regUrl;
	}
	public String getRegLog() {
		return regLog;
	}
	public void setRegLog(String regLog) {
		this.regLog = regLog;
	}
	public String getRegTitle() {
		return regTitle;
	}
	public void setRegTitle(String regTitle) {
		this.regTitle = regTitle;
	}
	public String getRegContent() {
		return regContent;
	}
	public void setRegContent(String regContent) {
		this.regContent = regContent;
	}
	public String getRegTime() {
		return regTime;
	}
	public void setRegTime(String regTime) {
		this.regTime = regTime;
	}
	public String getTitleReflectFunName() {
		return titleReflectFunName;
	}
	public void setTitleReflectFunName(String titleReflectFunName) {
		this.titleReflectFunName = titleReflectFunName;
	}
	public String getUrlReflectFunName() {
		return urlReflectFunName;
	}
	public void setUrlReflectFunName(String urlReflectFunName) {
		this.urlReflectFunName = urlReflectFunName;
	}
	public String getLogReflectFunName() {
		return logReflectFunName;
	}
	public void setLogReflectFunName(String logReflectFunName) {
		this.logReflectFunName = logReflectFunName;
	}
	public String getContentReflectFunName() {
		return contentReflectFunName;
	}
	public void setContentReflectFunName(String contentReflectFunName) {
		this.contentReflectFunName = contentReflectFunName;
	}
	public String getTimeReflectFunName() {
		return timeReflectFunName;
	}
	public void setTimeReflectFunName(String timeReflectFunName) {
		this.timeReflectFunName = timeReflectFunName;
	}

	public String getRegUrlOuter() {
		return regUrlOuter;
	}
	public void setRegUrlOuter(String regUrlOuter) {
		this.regUrlOuter = regUrlOuter;
	}
}
