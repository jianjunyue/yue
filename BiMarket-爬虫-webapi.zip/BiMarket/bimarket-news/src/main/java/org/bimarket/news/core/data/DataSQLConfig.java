package org.bimarket.news.core.data;

public class DataSQLConfig {
	private String dbTemplateName;
	private String dataSQL;
	private String countSQL;
	private Integer pagesize;

	public String getCountSQL() {
		return countSQL;
	}

	public void setCountSQL(String countSQL) {
		this.countSQL = countSQL;
	}

	public String getDataSQL() {
		return dataSQL;
	}

	public void setDataSQL(String dataSQL) {
		this.dataSQL = dataSQL;
	}

	public Integer getPagesize() {
		return pagesize;
	}

	public void setPagesize(Integer pagesize) {
		this.pagesize = pagesize;
	}

	public String getDbTemplateName() {
		return dbTemplateName;
	}

	public void setDbTemplateName(String dbTemplateName) {
		this.dbTemplateName = dbTemplateName;
	}
}
