package org.bimarket.news.core.handle;

import org.bimarket.news.core.model.DataInfo;

public class HandleCore_待定 {

	// 7、挖链https://www.walian.cn/（头条模块
	private static void news () {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("挖链");
		dataInfo.setSource_url("https://www.walian.cn/");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl_挖链");
		dataInfo.setLogReflectFunName("getLog");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrl("data-v-e0c4f160><a href=\"(.*?)\" target=\"_blank\"");
		dataInfo.setRegLog("data-v-e0c4f160><img src=\"(.*?)\" alt data-v-e0c4f160>");
		dataInfo.setRegTitle("<div class=\"title\" data-v-2b11b6f7>(.*?)</div>");
		dataInfo.setRegContent("<div class=\"content article\" data-v-2b11b6f7>(.*?)</div>");
		dataInfo.setRegTime("<div class=\"pub-time el-col el-col-4\" style=\"padding-left:5px;padding-right:5px;\" data-v-2b11b6f7>(.*?)</div>");
		NewsDown.handleNews(dataInfo);
	}
	
	// 12、巴比特http://www.8btc.com/
		private static DataInfo news_巴比特() {
			DataInfo dataInfo = new DataInfo();
			dataInfo.setSource("巴比特");
			dataInfo.setSource_url("http://www.8btc.com/blockchain/");
			dataInfo.setTitleReflectFunName("getTitle");
			dataInfo.setContentReflectFunName("getContent");
			dataInfo.setUrlReflectFunName("getUrl");
			dataInfo.setLogReflectFunName("getLog");
			dataInfo.setTimeReflectFunName("getTime");
			dataInfo.setRegUrl("<h2><a target=\"_blank\" href=\"(.*?)\">");
			dataInfo.setRegLog("data-original=\"(.*?)\"></img>");
			dataInfo.setRegTitle("<div class=\"article-title\">.*?h1>(.*?)</h1>");
			dataInfo.setRegContent("<div class=\"article-content\">(.*?)</div>");
			dataInfo.setRegTime("<time datetime=\".*?\">(.*?)</time></span>");
			return dataInfo;
		}

		//14、知链http://www.chainknow.com/
		private static DataInfo news_知链() {
			DataInfo dataInfo = new DataInfo();
			dataInfo.setSource("知链");
			dataInfo.setSource_url("http://www.chainknow.com/");
			dataInfo.setTitleReflectFunName("getTitle");
			dataInfo.setContentReflectFunName("getContent");
			dataInfo.setUrlReflectFunName("getUrl");
			dataInfo.setLogReflectFunName("getLog");
			dataInfo.setTimeReflectFunName("getTime");
			dataInfo.setRegUrl("<h3><a href=\"(.*?)\"");
			dataInfo.setRegLog("");
			dataInfo.setRegTitle("<h1>(.*?)</h1>");
			dataInfo.setRegContent("<div class=\"article-content\">(.*?)</div>");
			dataInfo.setRegTime("<span class=\"spanimg3\">(.*?)</span>");
			return dataInfo;
		}
}
