package org.bimarket.news.core.handle;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.news.core.data.NewsData;
import org.bimarket.news.core.model.DataInfo;
import org.bimarket.news.core.model.NewsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

public class NewsDown {
	private static final Logger logger = LoggerFactory.getLogger(NewsDown.class);

	public static void main(String[] args) {
		// DataInfo dataInfo = new DataInfo();
		// dataInfo.setSource("区块链新闻");
		// dataInfo.setSource_url("http://www.mingin.com/btc/news/");
		// dataInfo.setTitleReflectFunName("getTitle");
		// dataInfo.setContentReflectFunName("getContent");
		// dataInfo.setUrlReflectFunName("getUrl");
		// dataInfo.setLogReflectFunName("getLog");
		// dataInfo.setTimeReflectFunName("getTime");
		// dataInfo.setRegUrl("<h2 class=\"title ellipsis\"><a href=\"(.*?)\" target=\"_blank\">");
		// dataInfo.setRegTitle("<p class=\"title\">(.*?)</p>");
		// dataInfo.setRegContent("<div class=\"content\">(.*?)</div>");
		// dataInfo.setRegTime("<span class=\"color-gray\">(.*?)</span>");
		// handleNews(dataInfo);
		System.out.println("end");

	}

	public static void handleNews(DataInfo dataInfo) {
		List<NewsModel> urllist = handleNewsUrlList(dataInfo);
		for (NewsModel model : urllist) {
			model = getNewsInfo(dataInfo, model);
			NewsData.getData(model);
		}

	}

	private static String urlListOuterInfo(String info, String regUrlOuter) {
		try {
			Pattern pattern = Pattern.compile(regUrlOuter);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				String reuslt = matcher.group(1);
				if (reuslt.length() > 0) {
					info = reuslt;
				}
			}
		} catch (Exception e) {
			logger.error("NewsDown urlListOuterInfo is error", e);
		}
		return info;
	}

	public static List<NewsModel> handleNewsUrlList(DataInfo dataInfo) {
		List<NewsModel> urllist = new ArrayList<NewsModel>();
		try {
			String url = dataInfo.getSource_url();
			String info = HttpClientHelper.gethttpGet(url);
			info = urlListOuterInfo(info, dataInfo.getRegUrlOuter());
			String regUrl = dataInfo.getRegUrl();
			Pattern pattern = Pattern.compile(regUrl);
			Matcher matcher = pattern.matcher(info);

			Matcher logMatcher = getLogMatcherUrl(dataInfo.getRegLog(), info);
			while (matcher.find()) {
				try {
					String reuslt = matcher.group(1);
					reuslt = ReflectFun.getReflectFun(dataInfo.getUrlReflectFunName(), reuslt);
					if (!NewsData.exist(reuslt)) {
						NewsModel model = new NewsModel();
						model.setSource_url(reuslt);

						String log = "";
						if (logMatcher.find()) {
							if (logMatcher.groupCount() > 0) {
								log = logMatcher.group(1);
								log = ReflectFun.getReflectFun(dataInfo.getLogReflectFunName(), log);
							}
						}
						model.setLogo(log);
						urllist.add(model);
					}
				} catch (Exception e) {
					logger.error("RestaurantInfoData handleNewsUrlList is error", e);
				}
			}
		} catch (Exception e) {
			logger.error("NewsDown getData is error", e);
		}
		return urllist;
	}

	private static Matcher getLogMatcherUrl(String regLog, String info) {
		Pattern pattern = Pattern.compile(regLog);
		Matcher matcher = pattern.matcher(info);
		return matcher;
	}

	private static NewsModel getNewsInfo(DataInfo dataInfo, NewsModel model) {
		try {
			String info = HttpClientHelper.gethttpGet(model.getSource_url());

			String regTitle = dataInfo.getRegTitle();
			String title = getInfo(info, regTitle);
			title = ReflectFun.getReflectFun(dataInfo.getTitleReflectFunName(), title);

			String regContent = dataInfo.getRegContent();
			String content = getInfo(info, regContent);
			content = ReflectFun.getReflectFun(dataInfo.getContentReflectFunName(), content);

			String regTime = dataInfo.getRegTime();
			String time = getInfo(info, regTime);
			time = ReflectFun.getReflectFun(dataInfo.getTimeReflectFunName(), time);

			model.setContent(content);
			model.setSource(dataInfo.getSource());
			model.setTime(time);
			model.setTitle(title);
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return model;
	}

	public static String delHtmlTag(String str) {
		String newstr = "";
		newstr = str.replaceAll("<[.[^>]]*>", "");
		newstr = newstr.replaceAll(" ", "");
		return newstr;
	}

	private static String getInfo(String info, String regInfo) {
		String reuslt = "";
		try {
			Pattern pattern = Pattern.compile(regInfo);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt.trim();
	}

}
