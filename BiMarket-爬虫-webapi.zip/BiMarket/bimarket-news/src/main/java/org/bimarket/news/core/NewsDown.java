package org.bimarket.news.core;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.DateUtil;
import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.news.core.data.NewsData;
import org.bimarket.news.core.model.NewsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

public class NewsDown {
	private static final Logger logger = LoggerFactory.getLogger(NewsDown.class);

	public static void main(String[] args) {
		handleNews();
		System.out.println("end");

	}

	private static void handleNews() {
		List<String> urllist = handleNewsUrlList();
		for (String url : urllist) {
			NewsModel model = getNewsInfo(url);
			NewsData.getData(model);
		}

	}

	public static List<String> handleNewsUrlList() {
		List<String> urllist = new ArrayList<String>();
		try {
			String url = "http://www.ethchinese.com/?cat=23";
			String info = HttpClientHelper.gethttpGet(url).replace("\r\n", "");
			String regList = "<a href=\"(.*?)\" rel=\"bookmark\">";
			String reuslt = "";
			Pattern pattern = Pattern.compile(regList);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
				urllist.add(reuslt);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return urllist;
	}

	private static NewsModel getNewsInfo(String url) {
		NewsModel reuslt = new NewsModel();
		try {
			String info = HttpClientHelper.gethttpGet(url).replace("\r\n", "").replace("\r", "").replace("\n", "");
			// System.out.println(info);
			String regTitle = "<header class=\"entry-header clearfix\"><h1 class=\"entry-title\">(.*?)</h1>";
			String title = getInfo(info, regTitle);

			String regContent = "<div class=\"entry-content clearfix\">(.*?)<div class=\"open_social_box share_box\">";
			// String regContent = "entry-content clearfix(.*?)<p>";
			String content = getInfo(info, regContent);

			String regTime = "<span class=\"entry-meta-date updated\">(.*?)</span>";
			String time = getInfo(info, regTime);
			time = delHtmlTag(time).replace("年", "-").replace("月", "-").replace("日", "")+" 00:00:00";
			time = DateUtil.getFromString(time);
			reuslt.setContent(content);
			reuslt.setSource("以太中文网");
			reuslt.setSource_url(url);
			reuslt.setTime(time);
			reuslt.setTitle(title);
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt;
	}

	public static String delHtmlTag(String str) {
		String newstr = "";
		newstr = str.replaceAll("<[.[^>]]*>", "");
		newstr = newstr.replaceAll(" ", "");
		return newstr;
	}

	private static String getInfo(String info, String regInfo) {
		String reuslt = "";
		try {
			Pattern pattern = Pattern.compile(regInfo);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt.trim();
	}

}
