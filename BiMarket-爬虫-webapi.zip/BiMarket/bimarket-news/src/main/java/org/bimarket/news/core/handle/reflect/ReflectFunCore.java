package org.bimarket.news.core.handle.reflect;

import java.text.ParseException;

import org.bimarket.base.util.DateUtil;

public class ReflectFunCore {

	public String getUrl(String temp) {
		return temp;
	}

	public String getUrl_挖链(String temp) {
		return "https://www.walian.cn" + temp;
	}

	public String getUrl_Aicoin(String temp) {
		return "https://www.aicoin.net.cn" + temp;
	}

	public String getUrl_铅笔(String temp) {
		return "http://chainb.com/" + temp;
	}

	public String getUrl_链闻(String temp) {
		return "https://www.chainnews.com" + temp;
	}
	public String getUrl_莱比特资讯网(String temp) {
		return "http://www.bitcoin86.com" + temp;
	}
	public String getUrl_区块网(String temp) {
		return "http://www.qukuaiwang.com.cn" + temp;
	}

	public String getLog(String temp) {
		return temp;
	}

	public String getLog_链闻(String temp) {
		return temp.replace("(", "");
	}

	public String getLog_铅笔(String temp) {
		return "http://chainb.com" + temp;
	}
	public String getLogo_莱比特资讯网(String temp) {
		return "http://www.bitcoin86.com" + temp;
	}
	public String getLogo_区块网(String temp) {
		return "http://www.qukuaiwang.com.cn" + temp;
	}

	public String getTitle(String temp) {
		return temp.replace("'", "\"");
	}

	public String getContent(String temp) {
		return temp.replace("'", "\"");
	}

	public String getTime(String time) {
		try {
			time = time.replace("年", "-").replace("月", "-").replace("日", "").replace("/", "-");
			if (time == null || time.length() == 0) {
				time = DateUtil.getDateTimeFormat();
			} else if (time.length() == 10) {
				time = time + " 00:00:00";
			} else if (time.length() == 13) {
				time = time + ":00:00";
			} else if (time.length() == 16) {
				time = time + ":00";
			}

			time = DateUtil.getFromString(time);
		} catch (ParseException e) {
			time = DateUtil.getDateTimeFormat();
			e.printStackTrace();
		}
		return time;
	}

	public String getTime1(String time) {
		try {
			time = time.replace("·", "").trim().substring(0, 19);
			time = getTime(time);
		} catch (Exception e) {
			time = DateUtil.getDateTimeFormat();
			e.printStackTrace();
		}
		return time;
	}

	public String getTime_铅笔(String time) {
		try {
			time = time + "0";
			time = getTime(time);
		} catch (Exception e) {
			time = DateUtil.getDateTimeFormat();
			e.printStackTrace();
		}
		return time;
	}

	public String getTime_链闻(String time) {
		try {
			time = time + " 00:00:00";
			time = getTime(time);
		} catch (Exception e) {
			time = DateUtil.getDateTimeFormat();
			e.printStackTrace();
		}
		return time;
	}

	public String delHtmlTag(String str) {
		String newstr = "";
		newstr = str.replaceAll("<[.[^>]]*>", "");
		return newstr;
	}
}
