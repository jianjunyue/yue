package org.bimarket.news.core.handle;

import org.bimarket.news.core.model.DataInfo;

public class Test {

	public static void main(String[] args) {
		DataInfo dataInfo = news();
		NewsDown.handleNews(dataInfo);
		System.out.println("end!!!!");
	}
 
	//18、区块网http://www.qukuaiwang.com.cn/news.html
	private static DataInfo news() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("区块网");
		dataInfo.setSource_url("http://www.qukuaiwang.com.cn/news.html");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl_区块网");
		dataInfo.setLogReflectFunName("getLogo_区块网");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrlOuter("<div class=\"artList\">(.*?)</div>");
		dataInfo.setRegUrl("<a href=\"(.*?)\" class=\"img-article\"");
		dataInfo.setRegLog("<img onload=\"setImgWH(this)\" src=\"(.*?)\"/>");
		dataInfo.setRegTitle("<h1>(.*?)</h1>");
		dataInfo.setRegContent("<div class=\"content-art\">(.*?)<span style=\"font-size:16px;\">翻译");
		dataInfo.setRegTime("<p class=\"fl time-art\"><label></label>(.*?)</p>.*?<p class=\"view-count fl\"><label></label>");
		return dataInfo;
	}

}
