package org.bimarket.news.core.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bimarket.base.mysql.DataHelper;
import org.bimarket.news.core.model.NewsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
 

public class NewsData {
	private static final Logger logger = LoggerFactory.getLogger(NewsData.class);
	private static DataSQLConfig dataSQLConfig = null;

	/**
	 * 从napos原餐厅表读取餐厅配送范围信息
	 */
	public static List<Map<String, String>> getData(NewsModel model) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			if (model.getTitle().length() > 0 && model.getContent().length() > 0) {
				String dbtemplateName = "elemesearchDBTemplate";
				DataHelper dataHelper = new DataHelper();
				String sql = "select id from tb_news where title='" + model.getTitle() + "'";
				list = dataHelper.getDataFromDB(dbtemplateName, sql);
				if (list.size() == 0) {
					sql = "insert into tb_news(logo,title,intro,content,time,source,source_url,tags) values ('" + model.getLogo() + "','" + model.getTitle() + "','" + model.getIntro() + "','" + model.getContent() + "','" + model.getTime() + "','" + model.getSource() + "','" + model.getSource_url() + "','" + model.getTags() + "') ";
					dataHelper.update(dbtemplateName, sql);
				}
			} else {
				logger.error("NewsData getData is null. URL:" + model.getSource_url());
			}
		} catch (Exception e) {
			logger.error("NewsData getData is error", e);
			return null;
		}
		return list;
	}

	public static Boolean exist(String url) {
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "select id from tb_news where source_url='" + url + "'";
			System.out.println(sql);
			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			logger.error("NewsData exist is error", e);
		}
		return false;
	}

	private DataSQLConfig getDataSQLConfig() {
		if (dataSQLConfig == null) {
			try {
				String configPath = "/db/db-sql-bean.xml";
				String beanName = "restaurantDataSQLConfig";
				dataSQLConfig = (DataSQLConfig) getBeanObject(configPath, beanName);
			} catch (Exception e) {
				logger.error("RestaurantInfoData getDataSQLConfig is error", e);
			}
		}
		return dataSQLConfig;
	}

	private Object getBeanObject(String configPath, String beanName) {
		Object objBean = null;
		try {
			logger.info("DynamicConfig getBeanObject is starting - configPath:" + configPath + " , beanName:" + beanName);
			String newConfigPath = "conf" + configPath;
			@SuppressWarnings("resource")
			ApplicationContext ctx = new FileSystemXmlApplicationContext(newConfigPath);
			objBean = ctx.getBean(beanName);
			logger.info("DynamicConfig getBeanObject is end - configPath:" + configPath + " , beanName:" + beanName);
		} catch (Exception e) {
			logger.error("DynamicConfig getBeanObject is error", e);
		}
		return objBean;
	}
}
