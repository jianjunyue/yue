package org.bimarket.news.core.handle;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

public class ReflectFun {
	private static final Logger logger = LoggerFactory.getLogger(NewsDown.class);
	
//	private String regList;
//	private String regLog;
//	private String regTitle;
//	private String regContent;
//	private String regTime; 
 
	public static String getReflectFun(String reflectFunName, String para) {
		String name = "";
		try {
			if(reflectFunName.length()==0) { 
				return name;
			}
			Class cls = Class.forName("org.bimarket.news.core.handle.reflect.ReflectFunCore");
			Method m = cls.getDeclaredMethod(reflectFunName, new Class[] { String.class });
			Object object = m.invoke(cls.newInstance(), para);
			name = object.toString();
		} catch (Exception e) {
			logger.error("ReflectFun getName is error", e);
		}
		return name;
	} 
	 

	
	
}
