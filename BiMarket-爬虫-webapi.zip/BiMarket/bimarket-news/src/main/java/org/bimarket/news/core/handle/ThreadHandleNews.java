package org.bimarket.news.core.handle;

import org.bimarket.news.core.model.DataInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

public class ThreadHandleNews {
	private static final Logger logger = LoggerFactory.getLogger(ThreadHandleNews.class);

	private DataInfo dataInfo;

	public ThreadHandleNews(DataInfo dataInfo) {
		this.dataInfo = dataInfo;
	}

	public void run() {
		try {
			Thread thread = new Thread() {
				public void run() {
					run_news();
				}
			};
			thread.start();
		} catch (Exception e) {
			logger.error("ThreadHandleNews run is error", e);
		}
	}

	private void run_news() {
		try {
			while (true) {
				logger.info("ThreadHandleNews run_news starting");
				NewsDown.handleNews(dataInfo);
				logger.info("ThreadHandleNews run_news end");
				Thread.sleep(1000 * 60 * 10);
			}
		} catch (Exception e) {
			logger.error("ThreadHandleNews run_news is error", e);
		}
	}

}
