package org.bimarket.news.core;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.DateUtil;
import org.bimarket.base.util.FileUtil;
import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.news.core.data.NewsData;
import org.bimarket.news.core.model.NewsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

public class NewsDown3 {
	private static final Logger logger = LoggerFactory.getLogger(NewsDown3.class);

	public static void main(String[] args) {
		handleNews();
		System.out.println("end");

	}

	private static void handleNews() {
		List<String> urllist = handleNewsUrlList();
		for (String url : urllist) {
			NewsModel model = getNewsInfo(url);
			NewsData.getData(model);
		}

	}

	public static List<String> handleNewsUrlList() {
		List<String> urllist = new ArrayList<String>();
		try {
			String url = "http://www.mingin.com/btc/news/";
			String info = HttpClientHelper.gethttpGet(url);
			String regList = "<h2 class=\"title ellipsis\"><a href=\"(.*?)\" target=\"_blank\">";
			String reuslt = "";
			Pattern pattern = Pattern.compile(regList);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
				urllist.add( reuslt);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return urllist;
	}

	private static NewsModel getNewsInfo(String url) {
		NewsModel reuslt = new NewsModel();
		try {
			String info = HttpClientHelper.gethttpGet(url); 
			String regTitle = "<p class=\"title\">(.*?)</p>";
			String title = getInfo(info, regTitle);

			String regContent = "<div class=\"content\">(.*?)</div>"; 
			String content = getInfo(info, regContent);

			String regTime = "<span class=\"color-gray\">(.*?)</span>";
			String time = getInfo(info, regTime);
			time = time.replace("·", "").trim().substring(0,19);
			time = DateUtil.getFromString(time);
			reuslt.setContent(content);
			reuslt.setSource("区块链新闻");
			reuslt.setSource_url(url);
			reuslt.setTime(time);
			reuslt.setTitle(title);
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt;
	}

	public static String delHtmlTag(String str) {
		String newstr = "";
		newstr = str.replaceAll("<[.[^>]]*>", ""); 
		return newstr;
	}

	private static String getInfo(String info, String regInfo) {
		String reuslt = "";
		try {
			Pattern pattern = Pattern.compile(regInfo);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt.trim();
	}

}
