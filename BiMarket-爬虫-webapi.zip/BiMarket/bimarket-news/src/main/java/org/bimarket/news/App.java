package org.bimarket.news;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method; 
/**
 * Hello world!
 *
 * https://shimo.im/docs/rlMtqEsxxLkdYcRW
 */
public class App 
{
    public static void main( String[] args ) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException
    {
    	 Class cls = Class.forName("org.bimarket.news.core.handle.reflect.NameReflectFun");
    	 Method m = cls.getDeclaredMethod("getName1",new Class[]{String.class});  
    	 Object object= m.invoke(cls.newInstance(),"chb");
         System.out.println(object );
         System.out.println( "Hello World!" );
    }
}
//
//备注：
//1、爬虫数据必须去重
//2、爬虫的新闻必须标注最开始的新闻平台
//3、爬虫的数据必须带上新闻发布时间
//
//爬虫地址：
//1、 以太中文网http://www.ethchinese.com/?cat=23
//2、区块链资讯http://www.bitcoin86.com/block/
//3、sosobtc区块链新闻https://www.sosobtc.com/news/all
//4、区块链财经http://news.blockchain.hk/
//5、区块链新闻http://www.mingin.com/btc/news/
//6、金色财经http://www.jinse.com/（头条模块）
//7、挖链https://www.walian.cn/（头条模块）
//8、区块链探长http://view.inews.qq.com/a/TEC2018010502640100
//9、Aicoinhttps://www.aicoin.net.cn/news/all
//10、铅笔http://chainb.com/?P=sub&type=1
//11、链闻https://www.chainnews.com/
//12、巴比特http://www.8btc.com/
//13、价值区块链http://www.blockvalue.com/
//14、知链http://www.chainknow.com/
//15、玩币族http://www.wanbizu.com/
//16、新浪区块链频道http://tags.tech.sina.com.cn/%E5%8C%BA%E5%9D%97%E9%93%BE
//17、莱比特资讯网http://www.bitcoin86.com/szb/ltc/
//18、区块网http://www.qukuaiwang.com.cn/news.html
//19、链向财经https://www.chainfor.com/
//20、动趋动区https://www.blocktempo.com/
//21、 比特币中文网 http://btcif.com/
//22、区块客http://blockcast.it/
//23、链链财经http://www.o-o-o.link/portal.php
//24、币报道http://www.bibaodao.com/
//25、9个亿财经http://jgy.com/
//26、区块链大学https://qkldx.net/
//27、区块链掘金路http://www.07289.com/
//28、区块先生https://www.mrblock.tw/
//29、比特街http://bitejie.net/
//30、链头条http://www.chaintiao.com/
//31、鸵鸟区块链http://ico.tt/
//32、第一区块链http://etc.so/
//33、oheoshttp://www.oheos.com/
//34、比特快报http://www.blockbuf.com/
//35、今日币读https://bitread.today/
//36、区块链工作室http://qkl.studio/
//37、比特123http://news.btc123.com/news
//38、链世界https://www.7234.cn/
//39、未来财经http://www.weilaicaijing.com/
//40、彩云比特http://www.cybtc.com/
//41、挖趋网http://minerfun.com/portal.php
//42、汇讯网https://www.fxshell.com/
//43、比特币家园http://www.btc126.com/
//44、比特范http://news.btcfans.com/
//45、挖币网http://news.btcfans.com/
//46、币未来https://biweilai.com/
//47、币时https://www.timetocoin.com/
//48、因特链http://chainx.org/home
//49、以太坊爱好者https://ethfans.org/
//50、区块势https://blocktrend.today/
//51、链得得http://www.chaindd.com/
//
//
