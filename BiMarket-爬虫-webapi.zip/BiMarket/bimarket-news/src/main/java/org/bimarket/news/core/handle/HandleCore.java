package org.bimarket.news.core.handle;

import java.util.ArrayList;
import java.util.List;

import org.bimarket.news.core.model.DataInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

public class HandleCore {
	private static final Logger logger = LoggerFactory.getLogger(HandleCore.class);

	public static void main(String[] args) {
		logger.info("HandleCore is starting");
		HandleCore handleCore = new HandleCore();
		handleCore.threadRun();
		logger.info("HandleCore is end");
	}

	public void threadRun() {
		List<DataInfo> list = getDataInfoList();
		for (DataInfo dataInfo : list) {
			try {
				ThreadHandleNews threadHandleNews = new ThreadHandleNews(dataInfo);
				threadHandleNews.run();
			} catch (Exception e) {
				logger.error("HandleCore threadRun is error", e);
			}
		}
	}

	private List<DataInfo> getDataInfoList() {
		List<DataInfo> list = new ArrayList<DataInfo>();
		list.add(news_金色财经());
		list.add(news_Aicoin());
		list.add(news_铅笔());
		list.add(news_巴比特());
		list.add(news_玩币族());
		list.add(news_新浪区块链频道());
		list.add(news_莱比特资讯网());
		return list;
	}

	// 6、金色财经http://www.jinse.com/（头条模块）
	private DataInfo news_金色财经() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("金色财经");
		dataInfo.setSource_url("http://www.jinse.com/");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl");
		dataInfo.setLogReflectFunName("getLog");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrl("<a class=\"h3-ellipsis\" href=\"(.*?)\" target=\"_blank\"");
		dataInfo.setRegLog("<img class=\"lazy\" data-original=\"(.*?)\" alt=");
		dataInfo.setRegTitle("<h1 class=\"fontw font24\">(.*?)</h1>");
		dataInfo.setRegContent("<div class=\"con line30 font18\">(.*?)</div>");
		dataInfo.setRegTime("<span class=\"color-gray\">(.*?)</span>");
		return dataInfo;
	}

	// 9、Aicoinhttps://www.aicoin.net.cn/news/all
	private DataInfo news_Aicoin() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("Aicoin");
		dataInfo.setSource_url("https://www.aicoin.net.cn/news/all");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl_Aicoin");
		dataInfo.setLogReflectFunName("getLog");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrl("<h3 data-reactid=\".*?><a href=\"(.*?)\" target=\"_blank\"");
		dataInfo.setRegLog("<img src=\"(.*?)\" width=\"75\" height=\"60\">");
		dataInfo.setRegTitle("<header class=\"article-header\" data-reactid=\".*?\"><h2 data-reactid=\".*?\">(.*?)</h2>");
		dataInfo.setRegContent("<section class=\"article-main\" data-reactid=\".*?\">(.*?)</section>");
		dataInfo.setRegTime("<div class=\"pub-time el-col el-col-4\" style=\"padding-left:5px;padding-right:5px;\" data-v-2b11b6f7>(.*?)</div>");
		return dataInfo;
	}

	// 10、铅笔http://chainb.com/?P=sub&type=1
	private DataInfo news_铅笔() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("铅笔");
		dataInfo.setSource_url("http://chainb.com/?P=sub&type=1");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl_铅笔");
		dataInfo.setLogReflectFunName("getLog_铅笔");
		dataInfo.setTimeReflectFunName("getTime_铅笔");
		dataInfo.setRegUrl("<a class=\"transition\" href=\"(.*?)\" target=\"_blank\">");
		dataInfo.setRegLog("<img class=\"lazy\" data-original=\"(.*?)\" alt=\"");
		dataInfo.setRegTitle("<title>(.*?)</title>");
		dataInfo.setRegContent("<div id=\"article_content\" class=\"article-content-wrap\">(.*?)</div>");
		dataInfo.setRegTime("时间：<span class=\"author-name\">(.*?)</span>");
		return dataInfo;
	}

	// 11、链闻https://www.chainnews.com/
	private DataInfo news_链闻() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("链闻");
		dataInfo.setSource_url("https://www.chainnews.com/");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl_链闻");
		dataInfo.setLogReflectFunName("getLog_链闻");
		dataInfo.setTimeReflectFunName("getTime_链闻");
		dataInfo.setRegUrl("<div class=\"article-left\"><a href=\"(.*?)\" target=\"_blank\"");
		dataInfo.setRegLog("background-image:url(.*?)?imageView2");
		dataInfo.setRegTitle("<h1 class=\"title\" itemprop=\"headline\">(.*?)</h1>");
		dataInfo.setRegContent("<article class=\"gitbook-markdown-body\" itemprop=\"articleBody\">(.*?)</article>");
		dataInfo.setRegTime("<span class=\"publish-time\">(.*?)</span>");
		return dataInfo;
	}

	// 12、巴比特http://www.8btc.com/
	private DataInfo news_巴比特() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("巴比特");
		dataInfo.setSource_url("http://www.8btc.com/blockchain/");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl");
		dataInfo.setLogReflectFunName("getLog");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrl("<h2><a target=\"_blank\" href=\"(.*?)\">");
		dataInfo.setRegLog("data-original=\"(.*?)\"></img>");
		dataInfo.setRegTitle("<div class=\"article-title\">.*?h1>(.*?)</h1>");
		dataInfo.setRegContent("<div class=\"article-content\">(.*?)</div>");
		dataInfo.setRegTime("<time datetime=\".*?\">(.*?)</time></span>");
		return dataInfo;
	}

	// //13、价值区块链http://www.blockvalue.com/
	// private static DataInfo news_价值区块链() {
	// DataInfo dataInfo = new DataInfo();
	// dataInfo.setSource("价值区块链");
	// dataInfo.setSource_url("http://www.blockvalue.com/");
	// dataInfo.setTitleReflectFunName("getTitle");
	// dataInfo.setContentReflectFunName("getContent");
	// dataInfo.setUrlReflectFunName("getUrl");
	// dataInfo.setLogReflectFunName("getLog");
	// dataInfo.setTimeReflectFunName("getTime");
	// dataInfo.setRegUrlOuter("<ul class=\"list1\">(.*?)</ul>");
	// dataInfo.setRegUrl("<h2><a href=\"(.*?)\">");
	// dataInfo.setRegLog("");
	// dataInfo.setRegTitle("<h1>(.*?)</h1>");
	// dataInfo.setRegContent("<div class=\"content\">(.*?)</div>");
	// dataInfo.setRegTime("<small class=\"time\">(.*?)</small>");
	// return dataInfo;
	// }

	// 15、玩币族http://www.wanbizu.com/
	private DataInfo news_玩币族() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("玩币族");
		dataInfo.setSource_url("http://www.wanbizu.com/");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl");
		dataInfo.setLogReflectFunName("getLog");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrlOuter("<ul class=\"list1\">(.*?)</ul>");
		dataInfo.setRegUrl("<h2><a href=\"(.*?)\">");
		dataInfo.setRegLog("");
		dataInfo.setRegTitle("<h1>(.*?)</h1>");
		dataInfo.setRegContent("<div class=\"content\">(.*?)</div>");
		dataInfo.setRegTime("<small class=\"time\">(.*?)</small>");
		return dataInfo;
	}

	// 16、新浪区块链频道http://tags.tech.sina.com.cn/%E5%8C%BA%E5%9D%97%E9%93%BE
	private static DataInfo news_新浪区块链频道() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("新浪区块链频道");
		dataInfo.setSource_url("http://tags.tech.sina.com.cn/%E5%8C%BA%E5%9D%97%E9%93%BE");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl");
		dataInfo.setLogReflectFunName("getLog");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrlOuter("<ul class=\"feeds_list\">(.*?)</ul>");
		dataInfo.setRegUrl("<a href=\"(.*?)\" target=\"_blank\"");
		dataInfo.setRegLog("");
		dataInfo.setRegTitle("<h1 class=\"main-title\">(.*?)</h1>");
		dataInfo.setRegContent("<div class=\"article\" id=\"artibody\">(.*?)</div>");
		dataInfo.setRegTime("<span class=\"date\">(.*?)</span>");
		return dataInfo;
	}

	// 17、莱比特资讯网http://www.bitcoin86.com/szb/ltc/
	private static DataInfo news_莱比特资讯网() {
		DataInfo dataInfo = new DataInfo();
		dataInfo.setSource("莱比特资讯网");
		dataInfo.setSource_url("http://www.bitcoin86.com/szb/ltc/");
		dataInfo.setTitleReflectFunName("getTitle");
		dataInfo.setContentReflectFunName("getContent");
		dataInfo.setUrlReflectFunName("getUrl_莱比特资讯网");
		dataInfo.setLogReflectFunName("getLogo_莱比特资讯网");
		dataInfo.setTimeReflectFunName("getTime");
		dataInfo.setRegUrlOuter("<div class=\"content\">(.*?)</div>");
		dataInfo.setRegUrl("<a href='(.*?)' class='focus'");
		dataInfo.setRegLog("data-original='(.*?)'/></a>");
		dataInfo.setRegTitle("<h1 class=\"article-title\">(.*?)</h1>");
		dataInfo.setRegContent("<article class=\"article-content\">(.*?)</article>");
		dataInfo.setRegTime("<span class=\"item\">(.*?)</span>");
		return dataInfo;
	}
}
