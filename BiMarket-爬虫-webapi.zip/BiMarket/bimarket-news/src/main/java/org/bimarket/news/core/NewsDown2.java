package org.bimarket.news.core;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.DateUtil;
import org.bimarket.base.util.FileUtil;
import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.news.core.data.NewsData;
import org.bimarket.news.core.model.NewsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

public class NewsDown2 {
	private static final Logger logger = LoggerFactory.getLogger(NewsDown2.class);

	public static void main(String[] args) {
		handleNews();
		System.out.println("end");

	}

	private static void handleNews() {
		List<String> urllist = handleNewsUrlList();
		for (String url : urllist) {
			NewsModel model = getNewsInfo(url);
			NewsData.getData(model);
		}

	}

	public static List<String> handleNewsUrlList() {
		List<String> urllist = new ArrayList<String>();
		try {
			String url = "http://www.bitcoin86.com/block/";
			String info = HttpClientHelper.gethttpGet(url);
			String regList = "<a href='(.*?)' class='focus' target='_blank'>";
			String reuslt = "";
			Pattern pattern = Pattern.compile(regList);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
				urllist.add("http://www.bitcoin86.com"+reuslt);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return urllist;
	}

	private static NewsModel getNewsInfo(String url) {
		NewsModel reuslt = new NewsModel();
		try {
			String info = HttpClientHelper.gethttpGet(url); 
			String regTitle = "<h1 class=\"article-title\">(.*?)</h1>";
			String title = getInfo(info, regTitle);

			String regContent = "<article class=\"article-content\">(.*?)</article>"; 
			String content = getInfo(info, regContent);

			String regTime = "<div class=\"article-meta\">.*?<span class=\"item\">(.*?)</span>";
			String time = getInfo(info, regTime);
			time = delHtmlTag(time).replace("年", "-").replace("月", "-").replace("日", "")+" 00:00:00";
			time = DateUtil.getFromString(time);
			reuslt.setContent(content);
			reuslt.setSource("区块链资讯");
			reuslt.setSource_url(url);
			reuslt.setTime(time);
			reuslt.setTitle(title);
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt;
	}

	public static String delHtmlTag(String str) {
		String newstr = "";
		newstr = str.replaceAll("<[.[^>]]*>", "");
		newstr = newstr.replaceAll(" ", "");
		return newstr;
	}

	private static String getInfo(String info, String regInfo) {
		String reuslt = "";
		try {
			Pattern pattern = Pattern.compile(regInfo);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt.trim();
	}

}
