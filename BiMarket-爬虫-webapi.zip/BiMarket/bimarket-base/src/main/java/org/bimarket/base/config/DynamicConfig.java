package org.bimarket.base.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * 动态加载xml配置
 */
public class DynamicConfig {
	private static Logger logger = LoggerFactory.getLogger(DynamicConfig.class);

	/**
	 * 获取xml配置类
	 */
	public static Object getBeanObject(String configPath, String beanName) {
		Object objBean = null;
		try {
			logger.info("DynamicConfig getBeanObject is starting - configPath:" + configPath + " , beanName:" + beanName);
			String newConfigPath = "conf" + configPath;
			@SuppressWarnings("resource")
			ApplicationContext ctx = new FileSystemXmlApplicationContext(newConfigPath);
			objBean = ctx.getBean(beanName);
			logger.info("DynamicConfig getBeanObject is end - configPath:" + configPath + " , beanName:" + beanName);
		} catch (Exception e) {
			logger.error("DynamicConfig getBeanObject is error", e);
		}
		return objBean;
	}
}
