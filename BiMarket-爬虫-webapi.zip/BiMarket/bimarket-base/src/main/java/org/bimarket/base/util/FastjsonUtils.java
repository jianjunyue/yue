package org.bimarket.base.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON; 

public class FastjsonUtils {

	private static final Logger logger = LoggerFactory.getLogger(FastjsonUtils.class);

	public static <T> T jsonDeserialize(String json, Class<T> clazz) {
		T value = null;
		try {
			if (json != null && json.length() > 0) {
				value = JSON.parseObject(json, clazz);
			} else {
				logger.error("AlFastjsonUtils jsonDeserialize is error - json is null or emply!");
			}
		} catch (Exception e) {
			logger.error("FastjsonUtils jsonDeserialize is error", e);
			logger.error("FastjsonUtils jsonDeserialize is error - json:" + json);
		}
		return value;
	}

	public static String jsonSerialize(Object object) {
		String value = "";
		try {
			if (object != null) {
				value = JSON.toJSONString(object);
			}
		} catch (Exception e) {
			logger.error("FastjsonUtils jsonSerialize is error", e);
		}
		return value;
	}
}
