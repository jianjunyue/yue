package org.bimarket.base.mysql;
  
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler; 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataHelper {

	private static final Logger logger = LoggerFactory.getLogger(DataHelper.class);

	public List<Map<String, String>> getDataFromDB(String dbtemplateName, String sql) {
		JdbcTemplate jdbcTemplate = DbJdbcTemplate.getJdbcTemplate(dbtemplateName);

		final List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		jdbcTemplate.query(sql, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {

				int columCount = rs.getMetaData().getColumnCount();
				Map<String, String> obj = new HashMap<String, String>();
				try {
					String key;
					for (int i = 0; i < columCount; i++) {
						key = rs.getMetaData().getColumnName(i + 1).toLowerCase();
						if ("open_time".equals(key)) {
							obj.put(key, getOpenTime(rs.getBytes(key)));
						} else {
							obj.put(key, rs.getString(i + 1));
						}
					}

					result.add(obj);
				} catch (Exception e) {
					logger.error("DataHelper getDataFromDB processRow is error", e);
				}
			}
		});
		return result;
	}

	private String getOpenTime(byte[] bb) {
		String open_time = "";
		try {
			if (bb != null && bb.length > 0) {
				open_time = bytesToHexString(bb);
			}
		} catch (Exception e) {
			logger.error("DataHelper getOpenTime is error", e);
		}
		return open_time;
	}

	private String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder("");
		try {
			if (src == null || src.length == 0) {
				return null;
			}
			for (byte aSrc : src) {
				int v = aSrc & 0xff;
				String hv = Integer.toHexString(v);
				if (hv.length() < 2) {
					stringBuilder.append(0);
				}
				stringBuilder.append(hv);
			}
		} catch (Exception e) {
			logger.error("DataHelper bytesToHexString is error", e);
		}
		return stringBuilder.toString();
	}

	/**
	 * 获取数据数量
	 */
	public Long getDataCount(String dbtemplateName, String sql) {
		JdbcTemplate jdbcTemplate = DbJdbcTemplate.getJdbcTemplate(dbtemplateName);
		return jdbcTemplate.queryForObject(sql, Long.class);
	}

	/**
	 * 获取数据数量
	 */
	public Integer getDataCountInteger(String dbtemplateName, String sql) {
		JdbcTemplate jdbcTemplate = DbJdbcTemplate.getJdbcTemplate(dbtemplateName);
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

	public int select(String dbtemplateName, String sql) {
		JdbcTemplate jdbcTemplate = DbJdbcTemplate.getJdbcTemplate(dbtemplateName);
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

	/**
	 * 更新数据
	 */
	public int update(String dbtemplateName, String sql) {
		JdbcTemplate jdbcTemplate = DbJdbcTemplate.getJdbcTemplate(dbtemplateName);
		return jdbcTemplate.update(sql);
	}
}