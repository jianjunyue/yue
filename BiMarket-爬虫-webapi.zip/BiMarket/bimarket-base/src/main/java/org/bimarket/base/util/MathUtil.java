package org.bimarket.base.util;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
/**
 * @author yuejianjun
 */
public class MathUtil {

	private static final Logger logger = LoggerFactory.getLogger(MathUtil.class);

	/**
	 * second 是否比 first 小
	 */
	public static boolean floatCompare(String first, String second) {
		try {
			if (first == null || second == null) {
				return false;
			}

			float f1 = Float.parseFloat(first);
			float f2 = Float.parseFloat(second);
			return f2 < f1;
		} catch (Exception e) {
			logger.error("MathUtil floatCompare is error,  first=" + first + " , second=" + second, e);
		}
		return true;
	}

	public static double doubleParseObj(Object objdouble) {
		try {
			if (objdouble == null || objdouble.toString().length() == 0) {
				return 0;
			}

			return Double.parseDouble(objdouble.toString());
		} catch (Exception e) {
			logger.error("MathUtil doubleParse is error ,  objdouble=" + objdouble, e);
			logger.error(e.getMessage());
		}
		return 0;
	}

	public static double doubleParse(String strdouble) {
		try {
			if (strdouble.length() == 0) {
				return 0;
			}

			return Double.parseDouble(strdouble);
		} catch (Exception e) {
			logger.error("MathUtil doubleParse is error ,  strdouble=" + strdouble, e.getMessage()); 
		}
		return 0;
	}
	
	public static BigDecimal bigDecimalParse(String strBigDecimal) {
		try {
			if (strBigDecimal.length() == 0) {
				return new BigDecimal(0);
			}
			BigDecimal a=new BigDecimal(strBigDecimal);
			return a;
		} catch (Exception e) {
			logger.error("MathUtil bigDecimalParse is error ,  strBigDecimal=" + strBigDecimal, e.getMessage()); 
		}
		return new BigDecimal(0);
	}

	public static Float floatParse(Object objfloat) {
		try {
			return Float.parseFloat(objfloat.toString());
		} catch (Exception e) {
			logger.error("MathUtil floatParse is error - objfloat=" + objfloat, e.getMessage()); 
		}
		return 0f;
	}

	public static float floatParse(String strFloat) {
		try {
			if (strFloat != null) {
				return Float.parseFloat(strFloat);
			}
		} catch (Exception e) {
			logger.error("MathUtil floatParse is error - strFloat:" + strFloat);
		}
		return 0f;
	}

	public static Integer intParse(String strInt) {
		try {
			if (strInt != null) {
				return Integer.parseInt(strInt);
			}
		} catch (Exception e) {
			logger.error("MathUtil intParse is error ,  strInt=" + strInt);
		}
		return 0;
	}

	public static Integer intParse(String strInt, Integer def) {
		try {
			if (strInt == null) {
				return def;
			}

			return Integer.parseInt(strInt);
		} catch (Exception e) {
			logger.error("MathUtil intParse is error ,  strInt=" + strInt);
		}
		return def;
	}

	public static Long longParse(String strLong) {
		try {
			if (strLong == null) {
				return 0l;
			}
			return Long.parseLong(strLong);
		} catch (Exception e) {
			logger.error("MathUtil longParse is error ,  strLong=" + strLong);
		}
		return 0l;
	}

	public static Long longParse(String strLong, Long def) {
		try {
			if (strLong == null) {
				return 0l;
			}
			return Long.parseLong(strLong);
		} catch (Exception e) {
			logger.error("MathUtil longParse is error ,  strLong=" + strLong);
		}
		return def;
	}
}