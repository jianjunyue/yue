package org.bimarket.base.mysql;
   
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class DbJdbcTemplate {

	private static final Logger logger = LoggerFactory.getLogger(DbJdbcTemplate.class);

	public static JdbcTemplate getJdbcTemplate(String dbtemplateName) {
		try {
			Object objectJdbcTemplate = getObjectDbJdbcTemplate(dbtemplateName);
			JdbcTemplate jdbcTemplate =(JdbcTemplate) objectJdbcTemplate;
//			JdbcTemplate jdbcTemplate =new JdbcTemplate();// (JdbcTemplate) objectJdbcTemplate;
//			DataSource dataSource=new BasicDataSource();
//			dataSource.getConnection("root", "bilan1qaz@WSX"); 
////			dataSource.
//			jdbcTemplate.setDataSource(dataSource);
			 
			return jdbcTemplate;
		} catch (Exception e) {
			logger.error("DbJdbcTemplate.getJdbcTemplate is error ", e);
		}
		return null;

	}

	/**
	 * 数据库 DbJdbcTemplate
	 */
	public static Object getObjectDbJdbcTemplate(String dbtemplateName) {
		String configPath = "/db/db-bean.xml";
		Object dbJdbcTemplate = getBeanObject(configPath, dbtemplateName);
		return dbJdbcTemplate;
	}
	
	public static Object getBeanObject(String configPath, String beanName) {
		Object objBean = null;
		try {
			logger.info("DynamicConfig getBeanObject is starting - configPath:" + configPath + " , beanName:" + beanName);
			String newConfigPath = "conf" + configPath;
			@SuppressWarnings("resource")
			ApplicationContext ctx = new FileSystemXmlApplicationContext(newConfigPath);
			objBean = ctx.getBean(beanName);
			logger.info("DynamicConfig getBeanObject is end - configPath:" + configPath + " , beanName:" + beanName);
		} catch (Exception e) {
			logger.error("DynamicConfig getBeanObject is error", e);
		}
		return objBean;
	}
}
