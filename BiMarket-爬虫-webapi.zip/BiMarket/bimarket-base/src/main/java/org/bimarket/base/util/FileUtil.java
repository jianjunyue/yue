package org.bimarket.base.util;
 
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File; 
import java.io.IOException; 

public class FileUtil {
	private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);

	public void write(String filePath, String data) {
		File file = new File(filePath);
		try {
			FileUtils.writeStringToFile(file, data);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public String read(String filePath) {
		File file = new File(filePath);
		try {
			return FileUtils.readFileToString(file);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return "";
	}

	/**
	 * 得到Rtree索引文件目录
	 */
	public File[] getFiles(String dirPath) {
		File[] fs = null;
		try {
			File file = new File(dirPath);
			if (!file.exists()) {
				file.mkdirs();
			}
			fs = file.listFiles();
		} catch (Exception e) {
			logger.error("FileUtil getFiles is error", e);
		}
		return fs;
	}

}
