package org.bimarket.base.util;

import java.io.IOException;
import java.util.Date;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class HttpClientHelper {
	private static CloseableHttpClient httpClient = HttpClients.createDefault();

	public static void main(String[] args) {
		String httpapi = "";
		// httpapi="https://api.huobi.pro/market/depth?symbol=ethusdt&type=step1";
		// httpapi="https://api.huobi.pro/market/history/kline?period=1year&size=200&symbol=btcusdt";
		httpapi = "https://api.huobi.pro/market/history/kline?period=1min&size=200&symbol=btcusdt";

		 JSONObject jsonResult = httpGet(httpapi);
		// System.out.println(jsonResult.toJSONString());
		 System.out.println(jsonResult.get("data"));

//		Date dt = new Date();
//		Long time = dt.getTime();// 这就是距离1970年1月1日0点0分0秒的毫秒数
//		System.out.println(time);
//		System.out.println(System.currentTimeMillis());// 与上面的相同
//
//		Date dt1 = new Date(time);
//		String strDate = DateUtil.getDateTimeFormat(dt1);
//		System.out.println(strDate);
	}

	public static <T> T HttpGet(String api, Class<T> clazz) {
		T value = null;
		try {
			JSONObject jsonResult = httpGet(api);
			value = JSON.parseObject(jsonResult.toString(), clazz);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public static <T> T HttpPost(String api, Object postParams, Class<T> clazz) {
		T value = null;
		try {
			JSONObject jsonResult = httpPost(api, postParams);
			value = JSON.parseObject(jsonResult.toString(), clazz);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public static JSONObject httpGet(String api) {
		JSONObject jsonResult = null;
		HttpGet httpget = new HttpGet(api);

		CloseableHttpResponse response = null;
		try {
			response = httpClient.execute(httpget);
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				throw new RuntimeException("error http response code: " + statusCode);
			}

			String strResult = EntityUtils.toString(response.getEntity());
			jsonResult = JSONObject.parseObject(strResult);
			// return jsonResult.getJSONObject("data");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return jsonResult;
	}
	

	public static String gethttpGet(String url) {
		String strResult = "";
		HttpGet httpget = new HttpGet(url);

		CloseableHttpResponse response = null;
		try {
			response = httpClient.execute(httpget);
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				return "";
			}
			 String CHARSET = "UTF-8";
			  strResult = EntityUtils.toString(response.getEntity(),CHARSET); 
			// return jsonResult.getJSONObject("data");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return strResult.replace("\r\n", "").replace("\r", "").replace("\n", "");
	}

	public static JSONObject httpPost(String api, Object postParams) {
		JSONObject jsonResult = null;
		HttpPost httpPost = new HttpPost(api);
		CloseableHttpResponse response = null;
		try {
			String requestBody = JSON.toJSONString(postParams);
			httpPost.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));
			response = httpClient.execute(httpPost);
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				throw new RuntimeException("error http response code: " + statusCode);
			}

			String strResult = EntityUtils.toString(response.getEntity());
			System.out.println(strResult);
			jsonResult = JSONObject.parseObject(strResult);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return jsonResult;
	}
}
