package bilan.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import org.bilan.data.tb_currency.TbCurrencyData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import bilan.core.guava.CurrencyCacheHelper;
import bilan.core.guava.CurrencyListCacheHelper;
import bilan.core.guava.CurrencySearchListCacheHelper;

public class CurrencyCore {

	private static Logger logger = LoggerFactory.getLogger(CurrencyCore.class);

	/**
	 * 餐厅
	 */
	public List<Map<String, String>> getData(Integer start, Integer end) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			list = CurrencyListCacheHelper.getInstance().getCacheCurrencyList(start, end);
			if (list == null) {
				TbCurrencyData tbCurrencyData = new TbCurrencyData();
				list = tbCurrencyData.getData(start, end);
				if (list != null) {
					CurrencyListCacheHelper.getInstance().setCacheCurrencyList(start, end, list);
				}
			}
		} catch (Exception e) {
			logger.error("CurrencyCore getData is error", e); 
		}
		return list;
	}
	
	public List<Map<String, String>> getData(Integer start, Integer end,String keyWord) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			list = CurrencySearchListCacheHelper.getInstance().getCacheCurrencySearchList(start, end,keyWord);
			if (list == null) {
				TbCurrencyData tbCurrencyData = new TbCurrencyData();
				list = tbCurrencyData.getData(start, end,keyWord);
				if (list != null) {
					CurrencySearchListCacheHelper.getInstance().setCacheCurrencySearchList(start, end,keyWord,list);
				}
			}
		} catch (Exception e) {
			logger.error("CurrencyCore getData is error", e); 
		}
		return list;
	}
	
	public Map<String, String> getData(Integer id ) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			result = CurrencyCacheHelper.getInstance().getCacheCurrency(id);
			if (result == null) {
				TbCurrencyData tbCurrencyData = new TbCurrencyData();
				result = tbCurrencyData.getData(id);
				if (result != null) {
					CurrencyCacheHelper.getInstance().setCacheCurrency(id, result);
				}
			}
		} catch (Exception e) {
			logger.error("CurrencyCore getData is error", e); 
		}
		return result;
	}

}
