package bilan.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bilan.data.tb_currency.TbCurrencyData;
import org.bilan.data.tb_user_currency.TbUserCurrencyData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bilan.core.guava.CurrencyCacheHelper;
import bilan.core.guava.CurrencyListCacheHelper;
import bilan.core.guava.CurrencySearchListCacheHelper;
import bilan.core.guava.UserCurrencyListCacheHelper;

public class UserCurrencyCore {

	private static Logger logger = LoggerFactory.getLogger(UserCurrencyCore.class);

	/**
	 * 餐厅
	 */
	public List<Map<String, String>> getData(Integer start, Integer end, String xcxUserId) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			String open_id=OpenIdCore.getOpenId(xcxUserId);
			list = UserCurrencyListCacheHelper.getInstance().getCacheUserCurrencyList(start, end, open_id);
			if (list == null) {
				list = new ArrayList<Map<String, String>>();
				TbUserCurrencyData tbCurrencyData = new TbUserCurrencyData();
				List<Map<String, String>> listTemp = tbCurrencyData.getData(start, end, open_id);
				if (listTemp != null && listTemp.size() > 0) {
					CurrencyCore currencyCore = new CurrencyCore();
					for (Map<String, String> mapinfo : listTemp) {
						Integer currency_id = Integer.parseInt(mapinfo.get("currency_id"));
						Map<String, String> mapCurrencyInfo = currencyCore.getData(currency_id);
						list.add(mapCurrencyInfo);
					}
				}
				if (list != null && list.size() > 0) {
					UserCurrencyListCacheHelper.getInstance().setCacheUserCurrencyList(start, end, open_id, list);
				}
			}
		} catch (Exception e) {
			logger.error("UserCurrencyCore getData is error", e);
		}
		return list;
	}

	public int updateData(String xcxUserId, Integer currency_id, Integer is_delete) {
		int result = -100;
		try {
			String open_id=OpenIdCore.getOpenId(xcxUserId);
			TbUserCurrencyData tbCurrencyData = new TbUserCurrencyData();
			result = tbCurrencyData.updateData(open_id, currency_id, is_delete);
		} catch (Exception e) {
			logger.error("UserCurrencyCore updateData is error", e);
		}
		return result;
	}

}
