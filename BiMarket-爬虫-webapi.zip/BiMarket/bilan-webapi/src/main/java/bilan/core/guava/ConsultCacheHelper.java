package bilan.core.guava;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

public class ConsultCacheHelper {
	private static Logger logger = LoggerFactory.getLogger(ConsultCacheHelper.class);
	private static ConsultCacheHelper instance = new ConsultCacheHelper();
	private static LoadingCache<String, Map<String, String>> cacheConsult = null;

	public static ConsultCacheHelper getInstance() {
		if (instance == null) {
			instance.init();
		}
		return instance;
	}

	public Map<String, String> getCacheConsult(Integer id) {
		String key = "cacheConsult" + id  ;
		try {
			return cacheConsult.get(key);
		} catch (Exception e) {
			logger.error("ConsultListCacheHelper getCacheConsultList is error", e);
		}
		return null;
	}

	public void setCacheConsult(Integer id , Map<String, String> currency) {
		String key = "cacheConsult" + id  ;
		try {
			cacheConsult.put(key, currency);
		} catch (Exception e) {
			logger.error("ConsultListCacheHelper setCacheConsultList is error", e);
		}
	}

	private void init() {
		cacheConsult = (LoadingCache<String, Map<String, String>>) CacheBuilder.newBuilder().concurrencyLevel(8).expireAfterWrite(18, TimeUnit.SECONDS).initialCapacity(2).maximumSize(2).recordStats().removalListener(new RemovalListener<String, Map<String, String>>() {
			public void onRemoval(RemovalNotification<String, Map<String, String>> notification) {
				logger.info(notification.getKey() + " was removed, cause is " + notification.getCause());
			}
		}).build();

	}
}
