package bilan.core;

import java.util.Map;

import org.bilan.base.util.HttpsUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OpenIdCore {
	private static Logger logger = LoggerFactory.getLogger(OpenIdCore.class);

	public static String getxcxUserId(String code) {
		try {
			String uri = "https://api.weixin.qq.com/sns/jscode2session?appid=wx917cd1769b25b3ac&secret=62bf74434eb94ab04617ab5e82c13752&js_code=" + code + "&grant_type=authorization_code";
			Map<String, Object> openMap = HttpsUtil.getOpenIdMap(uri);
			String openid = "";
			if (openMap.containsKey("openid")) {
				openid = openMap.get("openid").toString();
			}
			String xcxUserId = getxcxUserIdjiami(openid);
			return xcxUserId;
		} catch (Exception e) {
			logger.error("OpenIdCore getxcxUserId is error", e);
		}
		return "";
	}

	private static String getxcxUserIdjiami(String openid) {
		return "111" + openid;
	}

	public static String getOpenId(String xcxUserId) {
		if (xcxUserId.length() > 3) {
			return xcxUserId.substring(3);
		} else {
			return xcxUserId;
		}
	}

}
