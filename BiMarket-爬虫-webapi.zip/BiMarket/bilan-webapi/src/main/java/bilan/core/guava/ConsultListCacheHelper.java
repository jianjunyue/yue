package bilan.core.guava;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

public class ConsultListCacheHelper {
	private static Logger logger = LoggerFactory.getLogger(ConsultListCacheHelper.class);
	private static ConsultListCacheHelper instance = new ConsultListCacheHelper();
	private static LoadingCache<String, List<Map<String, String>>> cacheConsultList = null;

	public static ConsultListCacheHelper getInstance() {
		if (instance == null) {
			instance.init();
		}
		return instance;
	}

	public List<Map<String, String>> getCacheConsultList(Integer start, Integer end) {
		String key = "cacheConsultList" + start + "_" + end;
		try {
			return cacheConsultList.get(key);
		} catch (Exception e) {
			logger.error("ConsultListCacheHelper getCacheConsultList is error", e);
		}
		return null;
	}

	public void setCacheConsultList(Integer start, Integer end, List<Map<String, String>> currencyList) {
		String key = "cacheConsultList" + start + "_" + end;
		try {
			cacheConsultList.put(key, currencyList);
		} catch (Exception e) {
			logger.error("ConsultListCacheHelper setCacheConsultList is error", e);
		}
	}

	private void init() {
		cacheConsultList = (LoadingCache<String, List<Map<String, String>>>) CacheBuilder.newBuilder().concurrencyLevel(8).expireAfterWrite(18, TimeUnit.SECONDS).initialCapacity(2).maximumSize(2).recordStats().removalListener(new RemovalListener<String, List<Map<String, String>>>() {
			public void onRemoval(RemovalNotification<String, List<Map<String, String>>> notification) {
				logger.info(notification.getKey() + " was removed, cause is " + notification.getCause());
			}
		}).build();

	}
}
