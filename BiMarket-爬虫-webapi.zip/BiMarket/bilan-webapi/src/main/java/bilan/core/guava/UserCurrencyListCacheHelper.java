package bilan.core.guava;

import java.util.List;
import java.util.Map; 
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

public class UserCurrencyListCacheHelper {
	private static Logger logger = LoggerFactory.getLogger(UserCurrencyListCacheHelper.class);
	private static UserCurrencyListCacheHelper instance = new UserCurrencyListCacheHelper();
	private static LoadingCache<String, List<Map<String, String>>> cacheUserCurrencyList = null;

	public static UserCurrencyListCacheHelper getInstance() {
		if (instance == null) {
			instance.init();
		}
		return instance;
	}

	public List<Map<String, String>> getCacheUserCurrencyList(Integer start, Integer end, String open_id) {
		String key = "cacheUserCurrencyList" + start + "_" + end+"_"+open_id;
		try {
			return cacheUserCurrencyList.get(key);
		} catch (Exception e) {
			logger.error("GuavaCacheHelper getCacheCurrencyList is error", e);
		}
		return null;
	}

	public void setCacheUserCurrencyList(Integer start, Integer end, String open_id, List<Map<String, String>> currencyList) {
		String key = "cacheUserCurrencyList" + start + "_" + end;
		try {
			cacheUserCurrencyList.put(key, currencyList);
		} catch (Exception e) {
			logger.error("GuavaCacheHelper setCacheCurrencyList is error", e);
		}
	}

	private void init() {
		cacheUserCurrencyList = (LoadingCache<String, List<Map<String, String>>>) CacheBuilder.newBuilder().concurrencyLevel(8).expireAfterWrite(18, TimeUnit.SECONDS).initialCapacity(2).maximumSize(2).recordStats().removalListener(new RemovalListener<String, List<Map<String, String>>>() {
			public void onRemoval(RemovalNotification<String, List<Map<String, String>>> notification) {
				logger.info(notification.getKey() + " was removed, cause is " + notification.getCause());
			}
		}).build();

	}
}
