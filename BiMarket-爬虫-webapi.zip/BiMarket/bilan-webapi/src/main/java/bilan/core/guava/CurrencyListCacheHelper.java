package bilan.core.guava;

import java.util.List;
import java.util.Map; 
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

public class CurrencyListCacheHelper {
	private static Logger logger = LoggerFactory.getLogger(CurrencyListCacheHelper.class);
	private static CurrencyListCacheHelper instance = new CurrencyListCacheHelper();
	private static LoadingCache<String, List<Map<String, String>>> cacheCurrencyList = null;

	public static CurrencyListCacheHelper getInstance() {
		if (instance == null) {
			instance.init();
		}
		return instance;
	}

	public List<Map<String, String>> getCacheCurrencyList(Integer start, Integer end) {
		String key = "cacheCurrencyList" + start + "_" + end;
		try {
			return cacheCurrencyList.get(key);
		} catch (Exception e) {
			logger.error("GuavaCacheHelper getCacheCurrencyList is error", e);
		}
		return null;
	}

	public void setCacheCurrencyList(Integer start, Integer end, List<Map<String, String>> currencyList) {
		String key = "cacheCurrencyList" + start + "_" + end;
		try {
			cacheCurrencyList.put(key, currencyList);
		} catch (Exception e) {
			logger.error("GuavaCacheHelper setCacheCurrencyList is error", e);
		}
	}

	private void init() {
		cacheCurrencyList = (LoadingCache<String, List<Map<String, String>>>) CacheBuilder.newBuilder().concurrencyLevel(8).expireAfterWrite(18, TimeUnit.SECONDS).initialCapacity(2).maximumSize(2).recordStats().removalListener(new RemovalListener<String, List<Map<String, String>>>() {
			public void onRemoval(RemovalNotification<String, List<Map<String, String>>> notification) {
				logger.info(notification.getKey() + " was removed, cause is " + notification.getCause());
			}
		}).build();

	}
}
