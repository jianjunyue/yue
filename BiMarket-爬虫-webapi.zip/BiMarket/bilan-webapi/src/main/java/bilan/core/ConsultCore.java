package bilan.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bilan.data.jdbc.DataHelper;
import org.bilan.data.model.DataSQLConfig;
import org.bilan.data.tb_consult.TbConsultData; 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bilan.core.guava.ConsultCacheHelper;
import bilan.core.guava.ConsultListCacheHelper; 

public class ConsultCore {

	private static Logger logger = LoggerFactory.getLogger(ConsultCore.class);

	/**
	 * 信息
	 */
	public List<Map<String, String>> getData(Integer start, Integer end) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			list = ConsultListCacheHelper.getInstance().getCacheConsultList(start, end);
			if (list == null) {
				TbConsultData tbConsultData = new TbConsultData();
				list = tbConsultData.getData(start, end);
				if (list != null) {
					ConsultListCacheHelper.getInstance().setCacheConsultList(start, end, list);
				}
			}
		} catch (Exception e) {
			logger.error("ConsultCore getData is error", e); 
		}
		return list;
	}

	public Map<String, String> getData(Integer id ) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			result = ConsultCacheHelper.getInstance().getCacheConsult(id);
			if (result == null) {
				TbConsultData tbConsultData = new TbConsultData();
				result = tbConsultData.getData(id);
				if (result != null) {
					ConsultCacheHelper.getInstance().setCacheConsult(id, result);
				}
			}
		} catch (Exception e) {
			logger.error("ConsultCore getData is error", e); 
		}
		return result;
	}
}
