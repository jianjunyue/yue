package bilan.controller;

import java.util.ArrayList; 
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
 
import bilan.core.UserCurrencyCore;

@Controller
public class CurrencyUserController {
	private static Logger logger = LoggerFactory.getLogger(CurrencyUserController.class);

	/**
	 * 货币信息列表
	 */
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/currencyuser/followcurrencylist.json")
	public byte[] followcurrencylist(Integer start, Integer end,String xcxUserId ) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			UserCurrencyCore currencyCore = new UserCurrencyCore();
			list = currencyCore.getData(start, end,xcxUserId);
			String strCurrency = JSON.toJSONString(list);
			return strCurrency.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("UserCurrencyController followcurrencylist is error", e);
		}
		return null;
	}
	
	/**
	 * 用户关注
	 * */
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/currencyuser/followcurrency.json")
	public byte[] followcurrency(String xcxUserId, Integer currency_id ) {
		int result = -100;
		try {
			Integer is_delete=0;//关注
			UserCurrencyCore currencyCore = new UserCurrencyCore();
			result = currencyCore.updateData(  xcxUserId,   currency_id,   is_delete) ;
			String strCurrency = JSON.toJSONString(result);
			return strCurrency.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController followcurrency is error", e);
		}
		return null;
	}
	
	
	/**
	 * 用户取消关注
	 * */
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/currencyuser/cancelfollowcurrency.json")
	public byte[] cancelfollowcurrency(String xcxUserId, Integer currency_id ) {
		int result = -100;
		try {
			Integer is_delete=-1;//取消关注
			UserCurrencyCore currencyCore = new UserCurrencyCore();
			result = currencyCore.updateData(  xcxUserId,   currency_id,   is_delete) ;
			String strCurrency = JSON.toJSONString(result);
			return strCurrency.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController cancelfollowcurrency is error", e);
		}
		return null;
	} 
	
}