package bilan.controller;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class HealthCheckController {
	private static Logger logger = LoggerFactory.getLogger(HealthCheckController.class);
	
	/**
	 * 健康检测
	 * */
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/check/healthCheck.json")
	public byte[]  healthCheck() {
	    String data = "博客";  
		try {         
			return data.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("HealthCheckController healthCheck is error", e);
		} 
		return null;
	}
}