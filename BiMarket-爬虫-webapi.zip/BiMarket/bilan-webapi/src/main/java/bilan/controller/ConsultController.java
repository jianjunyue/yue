package bilan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import bilan.core.ConsultCore; 

@Controller
public class ConsultController {
	private static Logger logger = LoggerFactory.getLogger(ConsultController.class);

	/**
	 * 货币信息列表
	 */
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/consult/consultlist.json")
	public byte[] consultlist(Integer start, Integer end) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			ConsultCore consultCore = new ConsultCore();
			list = consultCore.getData(start, end);
			String strConsult = JSON.toJSONString(list);
			return strConsult.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController consultlist is error", e);
		}
		return null;
	}
	
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/consult/consultinfo.json")
	public byte[] consultinfo(Integer id) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			ConsultCore consultCore = new ConsultCore();
			result = consultCore.getData(id);
			String strConsult = JSON.toJSONString(result);
			return strConsult.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController consultinfo is error", e);
		}
		return null;
	}
	
}