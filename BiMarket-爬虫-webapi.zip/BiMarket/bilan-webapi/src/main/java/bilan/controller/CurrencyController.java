package bilan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import bilan.core.CurrencyCore;

@Controller
public class CurrencyController {
	private static Logger logger = LoggerFactory.getLogger(CurrencyController.class);

	/**
	 * 货币信息列表
	 */
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/currency/currencylist.json")
	public byte[] currencylist(Integer start, Integer end) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			CurrencyCore currencyCore = new CurrencyCore();
			list = currencyCore.getData(start, end);
			String strCurrency = JSON.toJSONString(list);
			return strCurrency.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController currencylist is error", e);
		}
		return null;
	}
	
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/currency/currencysearchlist.json")
	public byte[] currencysearchlist(Integer start, Integer end,String keyword) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			CurrencyCore currencyCore = new CurrencyCore();
			list = currencyCore.getData(start, end,keyword);
			String strCurrency = JSON.toJSONString(list);
			return strCurrency.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController currencysearchlist is error", e);
		}
		return null;
	}
	
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET, value = "/currency/currencyinfo.json")
	public byte[] currencyinfo(Integer id) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			CurrencyCore currencyCore = new CurrencyCore();
			result = currencyCore.getData(id);
			String strCurrency = JSON.toJSONString(result);
			return strCurrency.getBytes("UTF-8");
		} catch (Exception e) {
			logger.error("CurrencyController currencyinfo is error", e);
		}
		return null;
	}
	
}