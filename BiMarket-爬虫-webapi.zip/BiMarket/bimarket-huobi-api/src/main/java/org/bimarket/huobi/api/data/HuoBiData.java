package org.bimarket.huobi.api.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bimarket.base.mysql.DataHelper;
import org.bimarket.huobi.api.model.MarketData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
 

public class HuoBiData {
	private static final Logger logger = LoggerFactory.getLogger(HuoBiData.class);
	private static DataSQLConfig dataSQLConfig = null;

	/**
	 * 从napos原餐厅表读取餐厅配送范围信息
	 */
	public static List<Map<String, String>> getData(MarketData marketData) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			sql = "select 1 from tb_bimarket_" + marketData.getPeriod() + " where ts_id=" + marketData.getId() + " and bi_type=" + marketData.getBi_type() + " and exchange_id=" + marketData.getExchange_type();
			list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 0) {
				sql = "insert into tb_bimarket_" + marketData.getPeriod() + "(ts_id,amount,count,open,close,low,high,vol,date_time,bi_type,exchange_id) values(" + marketData.getId() + "," + marketData.getAmount() + "," + marketData.getCount() + "," + marketData.getOpen() + "," + marketData.getClose() + "," + marketData.getLow() + "," + marketData.getHigh() + "," + marketData.getVol() + ",\"" + marketData.getDateTime() + "\"," + marketData.getBi_type() + "," + marketData.getExchange_type() + ") ";
				logger.info("HuoBiData getData - sql:" + sql);
				dataHelper.update(dbtemplateName, sql);
			} else {
				logger.info("HuoBiData getData 已经存在 ts_id:" + marketData.getId() + " , bi_type:" + marketData.getBi_type() + " , exchange_type:" + marketData.getExchange_type());
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
			return null;
		}
		return list;
	}

	private DataSQLConfig getDataSQLConfig() {
		if (dataSQLConfig == null) {
			try {
				String configPath = "/db/db-sql-bean.xml";
				String beanName = "restaurantDataSQLConfig";
				dataSQLConfig = (DataSQLConfig) getBeanObject(configPath, beanName);
			} catch (Exception e) {
				logger.error("RestaurantInfoData getDataSQLConfig is error", e);
			}
		}
		return dataSQLConfig;
	}

	private Object getBeanObject(String configPath, String beanName) {
		Object objBean = null;
		try {
			logger.info("DynamicConfig getBeanObject is starting - configPath:" + configPath + " , beanName:" + beanName);
			String newConfigPath = "conf" + configPath;
			@SuppressWarnings("resource")
			ApplicationContext ctx = new FileSystemXmlApplicationContext(newConfigPath);
			objBean = ctx.getBean(beanName);
			logger.info("DynamicConfig getBeanObject is end - configPath:" + configPath + " , beanName:" + beanName);
		} catch (Exception e) {
			logger.error("DynamicConfig getBeanObject is error", e);
		}
		return objBean;
	}
}
