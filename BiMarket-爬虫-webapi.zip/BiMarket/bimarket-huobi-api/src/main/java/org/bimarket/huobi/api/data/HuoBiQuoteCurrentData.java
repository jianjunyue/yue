package org.bimarket.huobi.api.data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.bimarket.base.mysql.DataHelper;
import org.bimarket.base.util.MathUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
/**
 * tb_quote_current 火币 实时更新
 */
public class HuoBiQuoteCurrentData {
	private static final Logger logger = LoggerFactory.getLogger(HuoBiQuoteCurrentData.class);

	/**
	 * 实时更新 tb_quote_current 表数据
	 */
	public static void updateTbQuoteCurrent(int bi_type, int exchange_type, double realPrice) {
		try {
			Date dt = new Date();
			long ts_current_time = dt.getTime()/1000;
			setPrice(bi_type, exchange_type, realPrice);
			setRose1h(bi_type, exchange_type, realPrice, ts_current_time);
			setRose24h(bi_type, exchange_type, realPrice, ts_current_time);
			setRose7d(bi_type, exchange_type, realPrice, ts_current_time);
			getHigh24hPrice(bi_type, exchange_type, ts_current_time);
			getLow24hPrice(bi_type, exchange_type, ts_current_time);
		} catch (Exception e) {
			logger.error("updateTbQuoteCurrent updateTbQuoteCurrent is error", e);
		}
	}

	/**
	 * 更新tb_quote_current 表 price 货币价格 （实时）
	 */
	private static int setPrice(int bi_type, int exchange_type, double price) {
		int result = -1;
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			sql = "select 1 from tb_quote_current where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 0) {
				sql = "insert into tb_quote_current(currency_id,exchange_id,price) values(" + bi_type + "," + exchange_type + ",\"" + price + "\"" + ") ";
			} else {
				sql = "update tb_quote_current set  price=\"" + price + "\"" + " where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			}
			logger.info("HuoBiQuoteCurrentData setPrice - sql:" + sql);
			result = dataHelper.update(dbtemplateName, sql);
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData setPrice is error", e);
			return -1;
		}
		return result;
	}

	/**
	 * 更新tb_quote_current 表 rose1h 涨幅(1h)
	 */
	private static int setRose1h(int bi_type, int exchange_type, double realPrice, long ts_current_time) {
		int result = -1;
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			int SECOND = 3600;
			long ts_id = ts_current_time - SECOND; // 一个小时前
			float rose1h = 0f;
			String table_type = "1min";
			double close_price = getClosePrice(bi_type, exchange_type, ts_id, table_type);
			if (close_price <= 0) {
				return -1;
			} else {
				rose1h = (float) ((realPrice - close_price) / close_price);
			}

			sql = "select 1 from tb_quote_current where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 0) {
				sql = "insert into tb_quote_current(currency_id,exchange_id,rose1h) values(" + bi_type + "," + exchange_type + ",\"" + rose1h + "\"" + ") ";
			} else {
				sql = "update tb_quote_current set  rose1h=\"" + rose1h + "\"" + " where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			}
			logger.info("HuoBiQuoteCurrentData setRose1h - sql:" + sql);
			result = dataHelper.update(dbtemplateName, sql);
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData setRose1h is error", e);
			return -1;
		}
		return result;
	}

	/**
	 * 更新tb_quote_current 表 rose24h 涨幅(24h)
	 */
	private static int setRose24h(int bi_type, int exchange_type, double realPrice, long ts_current_time) {
		int result = -1;
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			int SECOND = 3600 * 24;
			long ts_id = ts_current_time - SECOND; // 一个小时前
			float rose = 0f;
			String table_type = "1min";
			double close_price = getClosePrice(bi_type, exchange_type, ts_id, table_type);
			if (close_price <= 0) {
				return -1;
			} else {
				rose = (float) ((realPrice - close_price) / close_price);
			}

			sql = "select 1 from tb_quote_current where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 0) {
				sql = "insert into tb_quote_current(currency_id,exchange_id,rose24h) values(" + bi_type + "," + exchange_type + ",\"" + rose + "\"" + ") ";
			} else {
				sql = "update tb_quote_current set  rose24h=\"" + rose + "\"" + " where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			}
			logger.info("HuoBiQuoteCurrentData setRose1h - sql:" + sql);
			result = dataHelper.update(dbtemplateName, sql);
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData setRose1h is error", e);
			return -1;
		}
		return result;
	}

	/**
	 * 更新tb_quote_current 表 rose7d 涨幅(7d)
	 */
	private static int setRose7d(int bi_type, int exchange_type, double realPrice, long ts_current_time) {
		int result = -1;
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			int SECOND = 3600 * 24 * 7;
			long ts_id = ts_current_time - SECOND; // 一个小时前
			float rose = 0f;
			String table_type = "5min";
			double close_price = getClosePrice(bi_type, exchange_type, ts_id, table_type);
			if (close_price <= 0) {
				rose = 0f;
			} else {
				rose = (float) ((realPrice - close_price) / close_price);
			}

			sql = "select 1 from tb_quote_current where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 0) {
				sql = "insert into tb_quote_current(currency_id,exchange_id,rose7d) values(" + bi_type + "," + exchange_type + ",\"" + rose + "\"" + ") ";
			} else {
				sql = "update tb_quote_current set  rose7d=\"" + rose + "\"" + " where currency_id=" + bi_type + " and exchange_id=" + exchange_type;
			}
			logger.info("HuoBiQuoteCurrentData setRose1h - sql:" + sql);
			result = dataHelper.update(dbtemplateName, sql);
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData setRose1h is error", e);
			return -1;
		}
		return result;
	}

	private static double getClosePrice(int bi_type, int exchange_type, long ts_id, String table_type) {
		double result = -1;
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			sql = "select id,close from tb_bimarket_" + table_type + " where bi_type=" + bi_type + " and exchange_type=" + exchange_type + " and ts_id>" + ts_id + "  order by id  asc limit 1 ";

			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 1) {
				result = MathUtil.doubleParse(list.get(0).get("close"));
			}
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData getPrice is error", e);
			return -1;
		}
		return result;
	}

	/**
	 * high24h 24小时最高
	 */
	private static double getHigh24hPrice(int bi_type, int exchange_type, long ts_current_time) {
		double result = -1;
		try {
			int SECOND = 3600 * 24;
			long ts_id = ts_current_time - SECOND; // 一个小时前
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			sql = "select  max(close) as maxclose from tb_bimarket_1min where bi_type=" + bi_type + " and exchange_type=" + exchange_type + " and ts_id>" + ts_id;

			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 1) {
				double maxclose = MathUtil.doubleParse(list.get(0).get("maxclose"));

				sql = "update tb_quote_current set  high24h=\"" + maxclose + "\"" + " where currency_id=" + bi_type + " and exchange_id=" + exchange_type;

				logger.info("HuoBiQuoteCurrentData getHigh24hPrice - sql:" + sql);
				result = dataHelper.update(dbtemplateName, sql);
			}
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData getPrice is error", e);
			return -1;
		}
		return result;
	}

	/**
	 * low24h 24h最低
	 */
	private static double getLow24hPrice(int bi_type, int exchange_type, long ts_current_time) {
		double result = -1;
		try {
			int SECOND = 3600 * 24;
			long ts_id = ts_current_time - SECOND; // 一个小时前
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = "";
			sql = "select  min(close) as minclose from tb_bimarket_1min where bi_type=" + bi_type + " and exchange_type=" + exchange_type + " and ts_id>" + ts_id;

			List<Map<String, String>> list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 1) {
				double minclose = MathUtil.doubleParse(list.get(0).get("minclose"));
				sql = "update tb_quote_current set  low24h=\"" + minclose + "\"" + " where currency_id=" + bi_type + " and exchange_id=" + exchange_type;

				logger.info("HuoBiQuoteCurrentData getLow24hPrice - sql:" + sql);
				result = dataHelper.update(dbtemplateName, sql);
			}
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData getPrice is error", e);
			return -1;
		}
		return result;
	}

	
	/**
	 * turnover24h 24小时成交额
	 */
	public static double getTurnover24h(int bi_type, int exchange_type, BigDecimal vol) {
		double result = -1;
		try { 
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql = ""; 	
			sql = "update tb_quote_current set  turnover24h=" + vol +" where currency_id=" + bi_type + " and exchange_id=" + exchange_type;

			logger.info("HuoBiQuoteCurrentData getLow24hPrice - sql:" + sql);
			result = dataHelper.update(dbtemplateName, sql);
		} catch (Exception e) {
			logger.error("HuoBiQuoteCurrentData getPrice is error", e);
			return -1;
		}
		return result;
	}
	
}
