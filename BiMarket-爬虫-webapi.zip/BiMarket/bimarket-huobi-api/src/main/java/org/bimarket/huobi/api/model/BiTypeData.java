package org.bimarket.huobi.api.model;

public class BiTypeData {
	
	private int bi_type;
	private String bi_type_name;
	
	public int getBi_type() {
		return bi_type;
	}
	public void setBi_type(int bi_type) {
		this.bi_type = bi_type;
	}
	public String getBi_type_name() {
		return bi_type_name;
	}
	public void setBi_type_name(String bi_type_name) {
		this.bi_type_name = bi_type_name;
	}

}
