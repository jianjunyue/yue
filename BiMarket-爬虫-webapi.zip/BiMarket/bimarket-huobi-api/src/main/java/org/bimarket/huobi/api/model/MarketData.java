package org.bimarket.huobi.api.model;

public class MarketData { 
	private Long id;
	private double amount;
	private double count;
	private double open;
	private double close;
	private double low;
	private double high;
	private double vol;
	private String dateTime;
	
	private int bi_type; //币种数据类型 btcusdt->1, ethusdt->2, ltcusdt->3, etcusdt->4, bchusdt->5, ethbtc->6, ltcbtc->7, etcbtc->8, bchbtc->9
    private int exchange_type; //交易所类型 火币->1, 币安->2,bigone->3
	private String period;//K线周期 1min, 5min, 15min, 30min, 60min, 1day, 1mon, 1week, 1year
	
	public int getBi_type() {
		return bi_type;
	}
	public void setBi_type(int bi_type) {
		this.bi_type = bi_type;
	}
	public int getExchange_type() {
		return exchange_type;
	}
	public void setExchange_type(int exchange_type) {
		this.exchange_type = exchange_type;
	}
	
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	} 
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getCount() {
		return count;
	}
	public void setCount(double count) {
		this.count = count;
	}
	public double getOpen() {
		return open;
	}
	public void setOpen(double open) {
		this.open = open;
	}
	public double getClose() {
		return close;
	}
	public void setClose(double close) {
		this.close = close;
	}
	public double getLow() {
		return low;
	}
	public void setLow(double low) {
		this.low = low;
	}
	public double getHigh() {
		return high;
	}
	public void setHigh(double high) {
		this.high = high;
	}
	public double getVol() {
		return vol;
	}
	public void setVol(double vol) {
		this.vol = vol;
	}

}
