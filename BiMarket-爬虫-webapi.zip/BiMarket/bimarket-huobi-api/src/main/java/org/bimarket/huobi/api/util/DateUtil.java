package org.bimarket.huobi.api.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

//import me.ele.elog.Log;
//import me.ele.elog.LogFactory;

/**
 * @作者
 * @邮件
 * @日期 2014-2-2
 * @描述 日期工具类
 */
public class DateUtil {

//	private static final Log logger = LogFactory.getLog(DateUtil.class);

	/**
	 * 计算两个日期之间相差的分钟数
	 *
	 * @param smdate
	 *            较小的时间
	 * @param bdate
	 *            较大的时间
	 * @return 相差天数
	 * @throws ParseException
	 */
	public static long MinutesBetween(Date smdate, Date bdate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		smdate = sdf.parse(sdf.format(smdate));
		bdate = sdf.parse(sdf.format(bdate));
		Calendar cal = Calendar.getInstance();
		cal.setTime(smdate);
		long time1 = cal.getTimeInMillis();
		cal.setTime(bdate);
		long time2 = cal.getTimeInMillis();
		long betweenMinutes = (time2 - time1) / (1000 * 60);

		return betweenMinutes;
	}

	/**
	 * 计算两个日期之间相差的秒数
	 *
	 * @param smdate
	 *            较小的时间
	 * @param bdate
	 *            较大的时间
	 * @return 相差天数
	 * @throws ParseException
	 */
	public static long SecondBetween(Date smdate, Date bdate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		smdate = sdf.parse(sdf.format(smdate));
		bdate = sdf.parse(sdf.format(bdate));
		Calendar cal = Calendar.getInstance();
		cal.setTime(smdate);
		long time1 = cal.getTimeInMillis();
		cal.setTime(bdate);
		long time2 = cal.getTimeInMillis();
		long betweenSecond = (time2 - time1) / (1000);

		return betweenSecond;
	}

	/**
	 * 判断当前日期是星期几
	 *
	 * @param pTime
	 *            修要判断的时间
	 * @return dayForWeek 判断结果
	 * @Exception 发生异常
	 */
	public static int getWeekForToDay() {
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		int dayForWeek = 0;
		if (c.get(Calendar.DAY_OF_WEEK) == 1) {
			dayForWeek = 7;
		} else {
			dayForWeek = c.get(Calendar.DAY_OF_WEEK) - 1;
		}
		return dayForWeek;
	}

	/**
	 * 计算两个日期之间相差的天数
	 *
	 * @param smdate
	 *            较小的时间
	 * @param bdate
	 *            较大的时间
	 * @return 相差天数
	 * @throws ParseException
	 */
	public static int daysBetween(Date smdate, Date bdate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		smdate = sdf.parse(sdf.format(smdate));
		bdate = sdf.parse(sdf.format(bdate));
		Calendar cal = Calendar.getInstance();
		cal.setTime(smdate);
		long time1 = cal.getTimeInMillis();
		cal.setTime(bdate);
		long time2 = cal.getTimeInMillis();
		long between_days = (time2 - time1) / (1000 * 3600 * 24);

		return Integer.parseInt(String.valueOf(between_days));
	}


	/**
	 * 字符串的日期格式的计算
	 */
	public static int daysBetween(String smdate, String bdate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(sdf.parse(smdate));
		long time1 = cal.getTimeInMillis();
		cal.setTime(sdf.parse(bdate));
		long time2 = cal.getTimeInMillis();
		long between_days = (time2 - time1) / (1000 * 3600 * 24);

		return Integer.parseInt(String.valueOf(between_days));
	}

	/**
	 * <b>获取当前时间</b><br>
	 * y 年 M 月 d 日 H 24小时制 h 12小时制 m 分 s 秒
	 *
	 * @param format
	 *            日期格式
	 * @return
	 */
	public static String getCurrentDate(String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(new Date());
	}

	public static String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(new Date());
	}

	public static Date getDate() {
		return new Date();
	}

	/**
	 * 获取制定日期的格式化字符串
	 *
	 * @param date
	 *            Date 日期
	 * @param format
	 *            String 格式
	 * @return String
	 */
	public static String getFormatedDate(Date date, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}

	/**
	 * 判断哪个日期在前 如果日期一在日期二之前，返回true,否则返回false
	 *
	 * @param date1
	 *            日期一
	 * @param date2
	 *            日期二
	 * @return boolean
	 */
	public static boolean isBefore(Date date1, Date date2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date1);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(date2);

		if (c1.before(c2))
			return true;

		return false;
	}

	/**
	 * 将字符串转换成日期
	 *
	 * @param date
	 *            String 日期字符串
	 * @return Date
	 * @throws ParseException
	 */
	public static Date parseDateFromString(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.parse(date);
	}

	/**
	 * 字符串转化成日期时间
	 */
	public static Date getDateFromString(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.parse(date);
	}

	/**
	 * 获取指定月份的最后一天，
	 *
	 * @param date
	 *            Date类型
	 * @param date1
	 *            String类型 yyyy-MM-dd mm:HH:ss 或 yyyy-MM-dd
	 * @return Date
	 * @throws ParseException
	 */
	public static Date lastDayOfMonth(Date date, String date1) throws ParseException {
		Date _date = null;
		if (null != date)
			_date = date;
		if (null == date && null != date1)
			_date = parseDateFromString(date1);

		Calendar cal = Calendar.getInstance();
		cal.setTime(_date);
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		return cal.getTime();
	}

	/**
	 * 是否是闰年
	 *
	 * @param year
	 *            年份
	 * @return boolean
	 */
	public static boolean isLeapYear(int year) {
		GregorianCalendar calendar = new GregorianCalendar();
		return calendar.isLeapYear(year);
	}

	/**
	 * 当前时间字符串，格式：yyyy-MM-dd HH:mm:ss
	 */
	public static String getDateTimeFormat() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(date);
	} 

	/**
	 * 当前时间字符串，格式：yyyy-MM-dd HH:mm:ss
	 */
	public static String getDateTimeFormat(Date date) { 
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(date);
	}

	/**
	 * 当前时间字符串，格式：yyyy-MM-dd
	 */
	public static String getDateFormat() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return formatter.format(date);
	}

	/**
	 * 当前时间的小时
	 */
	@SuppressWarnings("deprecation")
	public static int getDateHours() {
		Date date = new Date();
		int hours = date.getHours();
		return hours;
	}


	/**
	 * 当前时间字符串，格式：HH:mm:ss
	 */
	public static String getTimeFormat() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		return formatter.format(date);
	}

	/**
	 * 当前时间数字，格式：HHmmss
	 */
	public static int getIntCurrentTime() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("HHmmss");
		return Integer.parseInt(formatter.format(date));
	}

	public static String getDateTimeFormat(String format) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(date);
	}

	/**
	 * 当前时间转换成long类型
	 */
	public static long getDateTimeLong() {
		Date date = new Date();
		return date.getTime();
	}

	/**
	 * 参数时间和时间类型转换成long类型
	 */
	public static long getDateTimeLong(String strdatetime, String format) throws ParseException {
		SimpleDateFormat dateformat = new SimpleDateFormat(format);
		Date date = null;
		date = dateformat.parse(strdatetime);
		return date.getTime();
	} 
	
	//////////////////////时间向后推迟///////////////////////////////// 

	/**
	 * 获取 Day 天之后时间  Day >0向后时间偏移；Day<0 向前偏移
	 */
	public static Date getDelayDay(Date beginDate, int Day) throws ParseException {
		SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar date = Calendar.getInstance();
		date.setTime(beginDate);
		date.set(Calendar.DATE, date.get(Calendar.DATE) + Day);// 把日期时间，整数往后推,负数往前移动
		Date endDate = dft.parse(dft.format(date.getTime()));
		return endDate;
	}

	/**
	 * 获取 hours 小时之后时间  hours >0向后时间偏移；hours<0 向前偏移
	 */
	public static Date getDelayHour(Date beginDate, int hours) throws ParseException {
		SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar date = Calendar.getInstance();
		date.setTime(beginDate);
		date.set(Calendar.HOUR, date.get(Calendar.HOUR) + hours);// 把日期时间，整数往后推,负数往前移动
		Date endDate = dft.parse(dft.format(date.getTime()));
		return endDate;
	}
	
	/**
	 * 获取 second 秒之后时间。 second >0向后时间偏移；second<0 向前偏移
	 */
	public static Date getDelaySecond(Date beginDate, int second) throws ParseException {
		SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar date = Calendar.getInstance();
		date.setTime(beginDate);
		date.set(Calendar.SECOND, date.get(Calendar.SECOND) + second);// 把日期时间，整数往后推,负数往前移动
		Date endDate = dft.parse(dft.format(date.getTime()));
		return endDate;
	} 


}