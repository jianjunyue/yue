package org.bimarket.huobi.api.model;

public class ExchangeTypeData {
	private int exchange_type;
	private String exchange_type_name; 
	
	public int getExchange_type() {
		return exchange_type;
	}
	public void setExchange_type(int exchange_type) {
		this.exchange_type = exchange_type;
	}
	public String getExchange_type_name() {
		return exchange_type_name;
	}
	public void setExchange_type_name(String exchange_type_name) {
		this.exchange_type_name = exchange_type_name;
	}

}
