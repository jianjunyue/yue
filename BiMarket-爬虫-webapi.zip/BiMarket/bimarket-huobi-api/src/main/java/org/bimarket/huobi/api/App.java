package org.bimarket.huobi.api;

import java.util.Date;

import org.bimarket.huobi.api.core.HouBiCore;
import org.bimarket.huobi.api.data.HuoBiQuoteCurrentData;
import org.bimarket.huobi.api.core.BiExchangeData;
import org.bimarket.huobi.api.model.BiTypeData;
import org.bimarket.huobi.api.model.ExchangeTypeData;
import org.bimarket.huobi.api.util.DateUtil;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws InterruptedException {

//		BiTypeData biTypeData = BiExchangeData.getBiTypeDatas().get(0);
//		ExchangeTypeData exchangeTypeData = BiExchangeData.getExchangeTypeDatas().get(0); 
//		HouBiCore.marketDetail(biTypeData, exchangeTypeData);
//		
//		 biTypeData = BiExchangeData.getBiTypeDatas().get(1);
//			  exchangeTypeData = BiExchangeData.getExchangeTypeDatas().get(0); 
//			HouBiCore.marketDetail(biTypeData, exchangeTypeData);
		run1();
		run2();
		run3();
		run4();
		 
		System.out.println("Hello World!");
	}
	
	public static void run1() {
		try {
			Thread thread = new Thread() {
				public void run() {
					getData_1min_btcusdt1_火币1();
				}
			};
			thread.start();
		} catch (Exception e) {
//			logger.error("FullIndexMonitor run is error", e);
		}
	}	
	public static void run2() {
		try {
			Thread thread = new Thread() {
				public void run() {
					getData_5min_btcusdt1_火币1();
				}
			};
			thread.start();
		} catch (Exception e) {
//			logger.error("FullIndexMonitor run is error", e);
		}
	}	
	public static void run3() {
		try {
			Thread thread = new Thread() {
				public void run() {
					getData_1min_ethusdt2_火币1();
				}
			};
			thread.start();
		} catch (Exception e) {
//			logger.error("FullIndexMonitor run is error", e);
		}
	}	
	public static void run4() {
		try {
			Thread thread = new Thread() {
				public void run() {
					getData_5min_ethusdt2_火币1();
				}
			};
			thread.start();
		} catch (Exception e) {
//			logger.error("FullIndexMonitor run is error", e);
		}
	}
	
	private static void getData_1min_btcusdt1_火币1() {
		Boolean updateRealPrice=true; //1min 实时更新 tb_quote_current 的price价格
		String period=BiExchangeData.getPeriods().get(0); 
		BiTypeData biTypeData = BiExchangeData.getBiTypeDatas().get(0);
		ExchangeTypeData exchangeTypeData = BiExchangeData.getExchangeTypeDatas().get(0); 
		HouBiCore.getData(period, biTypeData, exchangeTypeData,updateRealPrice);
	}	

	private static void getData_5min_btcusdt1_火币1() {
		String period=BiExchangeData.getPeriods().get(1); 
		BiTypeData biTypeData = BiExchangeData.getBiTypeDatas().get(0);
		ExchangeTypeData exchangeTypeData = BiExchangeData.getExchangeTypeDatas().get(0); 
		HouBiCore.getData(period, biTypeData, exchangeTypeData);
	}
	
	private static void getData_1min_ethusdt2_火币1() {
		Boolean updateRealPrice=true; //1min 实时更新 tb_quote_current 的price价格
		String period=BiExchangeData.getPeriods().get(0); 
		BiTypeData biTypeData = BiExchangeData.getBiTypeDatas().get(1);
		ExchangeTypeData exchangeTypeData = BiExchangeData.getExchangeTypeDatas().get(0); 
		HouBiCore.getData(period, biTypeData, exchangeTypeData,updateRealPrice);
	}	
	
	private static void getData_5min_ethusdt2_火币1() {
		String period=BiExchangeData.getPeriods().get(1); 
		BiTypeData biTypeData = BiExchangeData.getBiTypeDatas().get(1);
		ExchangeTypeData exchangeTypeData = BiExchangeData.getExchangeTypeDatas().get(0); 
		HouBiCore.getData(period, biTypeData, exchangeTypeData);
	}
	
	
	
}
