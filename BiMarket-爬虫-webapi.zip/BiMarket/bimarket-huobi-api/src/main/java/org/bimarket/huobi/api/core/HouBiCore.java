package org.bimarket.huobi.api.core;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bimarket.base.util.FastjsonUtils;
import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.base.util.MathUtil;
import org.bimarket.huobi.api.data.HuoBiData;
import org.bimarket.huobi.api.data.HuoBiQuoteCurrentData;
import org.bimarket.huobi.api.model.BiTypeData;
import org.bimarket.huobi.api.model.ExchangeTypeData;
import org.bimarket.huobi.api.model.MarketData;
import org.bimarket.huobi.api.util.DateUtil;

import com.alibaba.fastjson.JSONObject;

public class HouBiCore {
	
	public static void marketDetail(BiTypeData biTypeData, ExchangeTypeData exchangeTypeData) {
		String bi_type_name = biTypeData.getBi_type_name();
		int bi_type = biTypeData.getBi_type();
		String httpapi = "";
		httpapi = "https://api.huobi.pro/market/detail?symbol=" + bi_type_name;
		JSONObject jsonResult = HttpClientHelper.httpGet(httpapi);
		Map<String, Object> mapinfo=new HashMap<String, Object>() ;
		mapinfo = FastjsonUtils.jsonDeserialize(jsonResult.get("tick").toString(), HashMap.class);
		BigDecimal vol=MathUtil.bigDecimalParse(mapinfo.get("vol").toString());
		HuoBiQuoteCurrentData.getTurnover24h(bi_type, exchangeTypeData.getExchange_type(), vol);
	}
 
	public static void getData(String period, BiTypeData biTypeData, ExchangeTypeData exchangeTypeData, Boolean updateRealPrice) {
		String bi_type_name = biTypeData.getBi_type_name();
		int bi_type = biTypeData.getBi_type();
		String httpapi = "";
		httpapi = "https://api.huobi.pro/market/history/kline?period=" + period + "&size=100&symbol=" + bi_type_name;
		JSONObject jsonResult = HttpClientHelper.httpGet(httpapi);
		getMarketDataList(jsonResult.get("data"), period, bi_type, exchangeTypeData.getExchange_type(), updateRealPrice);
	}
	
	public static void getData(String period, BiTypeData biTypeData, ExchangeTypeData exchangeTypeData) {
		Boolean updateRealPrice = false;
		getData(period, biTypeData, exchangeTypeData, updateRealPrice);
	}

	private static List<MarketData> getMarketDataList(Object data, String period, int bi_type, int exchange_type, Boolean updateRealPrice) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		list = FastjsonUtils.jsonDeserialize(data.toString(), ArrayList.class);
		for (int i = 0; i < list.size(); i++) {
			Map<String, Object> mapData = list.get(i);
			MarketData marketData = new MarketData();
			marketData.setAmount(MathUtil.doubleParse(mapData.get("amount").toString()));
			marketData.setClose(MathUtil.doubleParse(mapData.get("close").toString()));
			marketData.setCount(MathUtil.doubleParse(mapData.get("count").toString()));
			marketData.setHigh(MathUtil.doubleParse(mapData.get("high").toString()));
			marketData.setId(MathUtil.longParse(mapData.get("id").toString()));
			marketData.setLow(MathUtil.doubleParse(mapData.get("low").toString()));
			marketData.setOpen(MathUtil.doubleParse(mapData.get("open").toString()));
			marketData.setVol(MathUtil.doubleParse(mapData.get("vol").toString()));
			Date dt = new Date(marketData.getId() * 1000);
			marketData.setDateTime(DateUtil.getDateTimeFormat(dt));

			marketData.setPeriod(period);
			marketData.setBi_type(bi_type);
			marketData.setExchange_type(exchange_type);
			HuoBiData.getData(marketData);
			if (updateRealPrice && i == 0) {
				HuoBiQuoteCurrentData.updateTbQuoteCurrent(marketData.getBi_type(), marketData.getExchange_type(), marketData.getClose());
			}
		}
		return null;
	}

}
