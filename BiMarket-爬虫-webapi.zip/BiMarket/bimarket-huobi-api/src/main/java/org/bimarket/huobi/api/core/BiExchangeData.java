package org.bimarket.huobi.api.core;

import java.util.ArrayList;
import java.util.List;

import org.bimarket.huobi.api.model.BiTypeData;
import org.bimarket.huobi.api.model.ExchangeTypeData;

public class BiExchangeData {
	
	/**
	 * K线周期 1min, 5min, 15min, 30min, 60min, 1day, 1mon, 1week, 1year
	 * */
	public static List<String> getPeriods(){ 
		List<String> list = new ArrayList<String>();
		list.add("1min");
//		list.add("5min");
		list.add("15min");
//		list.add("30min");
		list.add("60min");
		list.add("1day");
		list.add("1mon");
		list.add("1week");
		list.add("1year"); 
		
		return list;
	}

	/**
	 * 交易所类型 火币->1, 币安->2,bigone->3
	 */
	public static List<ExchangeTypeData> getExchangeTypeDatas() {
		List<ExchangeTypeData> list = new ArrayList<ExchangeTypeData>();

		ExchangeTypeData exchangeTypeData = new ExchangeTypeData();
		exchangeTypeData.setExchange_type(1);
		exchangeTypeData.setExchange_type_name("火币");
		list.add(exchangeTypeData);

		exchangeTypeData = new ExchangeTypeData();
		exchangeTypeData.setExchange_type(2);
		exchangeTypeData.setExchange_type_name("币安");
		list.add(exchangeTypeData);

		exchangeTypeData = new ExchangeTypeData();
		exchangeTypeData.setExchange_type(3);
		exchangeTypeData.setExchange_type_name("bigone");
		list.add(exchangeTypeData);

		return list;
	}

	/**
	 * 币种数据类型 btcusdt->1, ethusdt->2, ltcusdt->3, etcusdt->4, bchusdt->5, ethbtc->6, ltcbtc->7, etcbtc->8, bchbtc->9
	 */
	public static List<BiTypeData> getBiTypeDatas() {
		List<BiTypeData> list = new ArrayList<BiTypeData>();
		BiTypeData biTypeData = new BiTypeData();
		biTypeData.setBi_type(1);
		biTypeData.setBi_type_name("btcusdt");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(2);
		biTypeData.setBi_type_name("ethusdt");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(3);
		biTypeData.setBi_type_name("ltcusdt");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(4);
		biTypeData.setBi_type_name("etcusdt");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(5);
		biTypeData.setBi_type_name("bchusdt");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(6);
		biTypeData.setBi_type_name("ethbtc");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(7);
		biTypeData.setBi_type_name("ltcbtc");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(8);
		biTypeData.setBi_type_name("etcbtc");
		list.add(biTypeData);

		biTypeData = new BiTypeData();
		biTypeData.setBi_type(9);
		biTypeData.setBi_type_name("bchbtc");
		list.add(biTypeData);

		return list;
	}

}
