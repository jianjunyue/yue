package org.bimarket.huobi.api;

import java.math.BigDecimal;

import org.bimarket.base.util.MathUtil;

public class Test {

	public static void main(String[] args) {
		String aString="222539046.227093195900076787790000000000000000";
		BigDecimal a=new BigDecimal(0);
System.out.println(a);
System.out.println(a.toString());
	}

}
