package org.bimarket.binance.api;

/**
 * https://github.com/-exchange/binance-official-api-docs
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
