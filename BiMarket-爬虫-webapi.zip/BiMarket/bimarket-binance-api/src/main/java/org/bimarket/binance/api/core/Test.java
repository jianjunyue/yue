package org.bimarket.binance.api.core;

/**
 * https://api.binance.com/api/v1/klines?symbol=BNBBTC&interval=1m
 * */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
