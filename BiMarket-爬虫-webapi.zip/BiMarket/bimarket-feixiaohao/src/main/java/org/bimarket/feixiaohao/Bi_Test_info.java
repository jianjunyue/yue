package org.bimarket.feixiaohao;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.HttpClientHelper;

public class Bi_Test_info {

	public static void main(String[] args) {
		String url = "https://www.feixiaohao.com/currencies/ethereum/"; 
		String str=HttpClientHelper.gethttpGet(url); 
		str=str.replace("\r\n", "");
		getname(  str);
		getname_cn(  str);

		System.out.println("end");
	}
	
	/**
	 * <span class="tags-red">-0.11%</span></div> 
	 * */
	public static String handleBi(String str) {
		String regTable = "<span class=\"tags-red\">(.*?)</span></div>";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(str);
		while (matcher.find()) {
			reuslt = matcher.group(1);
			System.out.println(reuslt);
		}
		return reuslt;
	}
	
	/**
	 * <div class="cell maket"> </h1>  
	 * */
	public static String handleBi1(String str) {
		str=str.replace("\r\n", "");
		String regTable = "<div class=\"cell maket\">(.*?)</div>";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(str);
		Boolean find=matcher.find();
		while (find) {
			reuslt = matcher.group(1);
			System.out.println(reuslt);
			find=matcher.find();
		}
		return reuslt;
	}
	
	private static String getname(String pageinfo) {
		String regTable = "<div class=\"cell maket\">.*?\">(.*?)<input type=";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(pageinfo);
		while (matcher.find()) {
			reuslt = matcher.group(1); 
			System.out.println(reuslt);
		}
		return reuslt;
	}
	
	private static String getname_cn(String pageinfo) {
		String regTable = "<input type=\"hidden\" id=\"coinname\".*?\">(.*?)</h1>";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(pageinfo);
		while (matcher.find()) {
			reuslt = matcher.group(1); 
			System.out.println(reuslt);
		}
		return reuslt;
	}
	
	private static String getname_short(String pageinfo) {
		String regTable = "<div class=\"cell maket\">.*?<img src=\"(.*?)\" alt=";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(pageinfo);
		while (matcher.find()) {
			reuslt = matcher.group(1); 
			System.out.println(reuslt);
		}
		return reuslt;
	}
	
	private static String getmarket_price(String pageinfo) {
		String regTable = "<div class=\"cell maket\">.*?<img src=\"(.*?)\" alt=";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(pageinfo);
		while (matcher.find()) {
			reuslt = matcher.group(1); 
			System.out.println(reuslt);
		}
		return reuslt;
	}
	
	 
}
