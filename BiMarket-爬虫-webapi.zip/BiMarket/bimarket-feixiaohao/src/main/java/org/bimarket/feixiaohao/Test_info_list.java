//package org.bimarket.feixiaohao;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//import org.bimarket.base.util.FastjsonUtils;
//import org.bimarket.base.util.HttpClientHelper;
//import org.bimarket.feixiaohao.core.model.CurrencyModel;
//
//public class Test_info_list {
//
//	public static void main(String[] args) {
//		String url = "https://www.feixiaohao.com/list_1.html"; 
//		String str=HttpClientHelper.gethttpGet(url);
//		str=str.replace("\r\n", "");
//		handleBi(  str);
//
//		System.out.println("end");
//	}
//	
//	/**
//	 * <a href="/currencies/bitcoin/"  target="_blank">
//	 * */
//	public static List<CurrencyModel> handleBi(String str) {
//		List<CurrencyModel> list=new ArrayList<>();
//		String regTable = "<tr id=\"(.*?)</tr>";
//		String reuslt = "";
//		Pattern pattern = Pattern.compile(regTable);
//		Matcher matcher = pattern.matcher(str);
//		while (matcher.find()) {
//			reuslt = matcher.group(0);
////			System.out.println(reuslt);
//			CurrencyModel currencyModel=getCurrencyModel(reuslt);
//			list.add(currencyModel);
//		}
//		return list;
//	}
//	
//	private static CurrencyModel getCurrencyModel(String info) {
//		CurrencyModel currencyModel=new CurrencyModel();
//		
//		//<a href="/currencies/bitcoin/"  target="_blank">
//		String regTable = "<a href=\"(.*?)/\"  target=\"_blank\">";
//		currencyModel.setFeixiaohao_currency_url(getInfo( info,  regTable ));
//		
//		 regTable = "<img src=\"(.*?)\" alt=\"";
//		 currencyModel.setCurrency_logo(getInfo( info,  regTable ));
//		 
//		 regTable = "<img src=\".*?\" alt=\"(.*?)\">";
//		 currencyModel.setName_cn(getInfo( info,  regTable ));
//		 
//		 regTable = "<tr id=\".*?\">.*?<td>(.*?)</td>";
//		 currencyModel.setPriority(getInfo( info,  regTable ));
//		 
//		 regTable = "<td  class=\"market-cap\" data-usd=\".*?\" data-cny=\".*?\".*?\">(.*?)</td>";
//		 currencyModel.setMarket_price(getInfo( info,  regTable ));
//		 
//		 regTable = "target=\"_blank\" class=\"price\".*?data-btc=\".*?\">(.*?)</a></td>";
//		 currencyModel.setPrice(getInfo( info,  regTable ));
//		 
//		 regTable = "target=\"_blank\" class=\"price\".*?</a></td><td>(.*?)</td>";
//		 currencyModel.setMarket_num(getInfo( info,  regTable ));
//		 
//		 regTable = "class=\"volume\".*?>(.*?)</a></td>";
//		 currencyModel.setTurnover24h(getInfo( info,  regTable ));
//		 
//		 
//		 
//		 System.out.println("------------------------------------------");
//		 System.out.println(FastjsonUtils.jsonSerialize(currencyModel));
//		return currencyModel;
//	}
//	
//	private static String getInfo(String info,String regTable ) { 
//		String reuslt = "";
//		Pattern pattern = Pattern.compile(regTable);
//		Matcher matcher = pattern.matcher(info);
//		while (matcher.find()) {
//			reuslt = matcher.group(1);
//		}
//		return reuslt.trim();
//	}
//	
//}
