package org.bimarket.feixiaohao.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bimarket.base.mysql.DataHelper;
import org.bimarket.feixiaohao.core.model.CurrencyModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
 

public class CurrencyModelData {
	private static final Logger logger = LoggerFactory.getLogger(CurrencyModelData.class);
	private static DataSQLConfig dataSQLConfig = null;

	/**
	 * 从napos原餐厅表读取餐厅配送范围信息
	 */
	public static List<Map<String, String>> getData(CurrencyModel currencyModel) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			String dbtemplateName = "elemesearchDBTemplate";
			DataHelper dataHelper = new DataHelper();
			String sql_tb_currency_meta = "";
			String sql_tb_currency = "";
			String currency_id = "";
			String sql = "select currency_id from tb_currency_meta where name='" + currencyModel.getName() + "'";
			list = dataHelper.getDataFromDB(dbtemplateName, sql);
			if (list.size() == 0) {
				sql_tb_currency_meta = "insert into tb_currency_meta(name,name_ch,name_short,priority,currency_home,currency_logo,description) values ('" + currencyModel.getName() + "','" + currencyModel.getName_cn() + "','" + currencyModel.getName_short() + "','" + currencyModel.getPriority() + "','" + currencyModel.getFeixiaohao_currency_url() + "','" + currencyModel.getCurrency_logo() + "','" + currencyModel.getDescribe() + "') ";
				dataHelper.update(dbtemplateName, sql_tb_currency_meta);
				sql = "select currency_id from tb_currency_meta where name='" + currencyModel.getName() + "'";
				list = dataHelper.getDataFromDB(dbtemplateName, sql);
				currency_id = list.get(0).get("currency_id");
			} else {
				currency_id = list.get(0).get("currency_id");
				sql_tb_currency_meta = "update tb_currency_meta set name_ch='" + currencyModel.getName_cn() + "', name_short='" + currencyModel.getName_short()+ "', priority='" + currencyModel.getPriority() + "', currency_home='" + currencyModel.getFeixiaohao_currency_url() + "', currency_logo='" + currencyModel.getCurrency_logo() + "', description='" + currencyModel.getDescribe() + "' where currency_id='" + currency_id + "' ";
				dataHelper.update(dbtemplateName, sql_tb_currency_meta);
			}
			if (currency_id.length() > 0) {
				sql = "select currency_id from tb_currency where currency_id='" + currency_id + "'";
				list = dataHelper.getDataFromDB(dbtemplateName, sql);
				if (list.size() == 0) {
					sql_tb_currency = "insert into tb_currency(market_price,price,market_num,currency_id) values ('" + currencyModel.getMarket_price() + "','" + currencyModel.getPrice() + "','" + currencyModel.getMarket_num() + "','" + currency_id + "' ) ";
					dataHelper.update(dbtemplateName, sql_tb_currency);
				} else {
					sql_tb_currency = "update tb_currency set market_price='" + currencyModel.getMarket_price() + "', price='" + currencyModel.getPrice() + "', market_num='" + currencyModel.getMarket_num() + "' where currency_id='" + currency_id + "' ";
					dataHelper.update(dbtemplateName, sql_tb_currency);
				}
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
			return null;
		}
		return list;
	}

	private DataSQLConfig getDataSQLConfig() {
		if (dataSQLConfig == null) {
			try {
				String configPath = "/db/db-sql-bean.xml";
				String beanName = "restaurantDataSQLConfig";
				dataSQLConfig = (DataSQLConfig) getBeanObject(configPath, beanName);
			} catch (Exception e) {
				logger.error("RestaurantInfoData getDataSQLConfig is error", e);
			}
		}
		return dataSQLConfig;
	}

	private Object getBeanObject(String configPath, String beanName) {
		Object objBean = null;
		try {
			logger.info("DynamicConfig getBeanObject is starting - configPath:" + configPath + " , beanName:" + beanName);
			String newConfigPath = "conf" + configPath;
			@SuppressWarnings("resource")
			ApplicationContext ctx = new FileSystemXmlApplicationContext(newConfigPath);
			objBean = ctx.getBean(beanName);
			logger.info("DynamicConfig getBeanObject is end - configPath:" + configPath + " , beanName:" + beanName);
		} catch (Exception e) {
			logger.error("DynamicConfig getBeanObject is error", e);
		}
		return objBean;
	}
}
