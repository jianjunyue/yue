package org.bimarket.feixiaohao.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.FastjsonUtils;
import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.base.util.MathUtil;
import org.bimarket.feixiaohao.core.model.CurrencyModel;
import org.bimarket.feixiaohao.data.CurrencyModelData;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class HomePageListCore {
	private static final Logger logger = LoggerFactory.getLogger(HomePageListCore.class);

	public static void main(String[] args) {
		handleBiList();
		System.out.println("end");
	}

	public static void handleBiList() {
		for (int i = 0; i < 20; i++) {
			try {
				String url = "https://www.feixiaohao.com/list_" + i + ".html";
				String http = HttpClientHelper.gethttpGet(url).replace("\r\n", "");
				List<CurrencyModel> list = handleBi(http);
				for (CurrencyModel currencyModel : list) {
					CurrencyModelData.getData(currencyModel);
				}
			} catch (Exception e) {
				logger.error("RestaurantInfoData getData is error", e);
			}
		}
	}

	public static List<CurrencyModel> handleBi(String str) {
		List<CurrencyModel> list = new ArrayList<CurrencyModel>();
		try {
			String regTable = "<tr id=\"(.*?)</tr>";
			String reuslt = "";
			Pattern pattern = Pattern.compile(regTable);
			Matcher matcher = pattern.matcher(str);
			while (matcher.find()) {
				reuslt = matcher.group(0);
				CurrencyModel currencyModel = getCurrencyModel(reuslt);
				currencyModel = HomePageCore.getBiCurrencyModel(currencyModel.getFeixiaohao_currency_url(), currencyModel);
				list.add(currencyModel);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return list;
	}

	private static CurrencyModel getCurrencyModel(String info) {
		CurrencyModel currencyModel = new CurrencyModel();
		try {
			// <a href="/currencies/bitcoin/" target="_blank">
			String regTable = "<a href=\"(.*?)/\"  target=\"_blank\">";
			currencyModel.setFeixiaohao_currency_url(getInfo(info, regTable));

			regTable = "<img src=\"(.*?)\" alt=\"";
			String logo = getInfo(info, regTable);
			if (logo.length() > 0) {
				logo = "https:" + logo;
			}
			currencyModel.setCurrency_logo(logo);

			regTable = "<img src=\".*?\" alt=\"(.*?)\">";
			String name = getInfo(info, regTable);
			String name_cn = name;// 中文名称
			String name_short = name;// 简称
			if (name.split("-").length == 2) {
				name_short = name.split("-")[0];
				name_cn = name.split("-")[1];
			}
			currencyModel.setName_cn(name_cn);
			currencyModel.setName_short(name_short);

			regTable = "<tr id=\".*?\">.*?<td>(.*?)</td>";
			currencyModel.setPriority(getInfo(info, regTable));

			regTable = "<td  class=\"market-cap\" data-usd=\".*?\" data-cny=\".*?\".*?\">(.*?)</td>";
			String Market_price=getInfo(info, regTable).replace("¥", "").replace(",", "").replace("亿", "");
			currencyModel.setMarket_price(MathUtil.doubleParse(Market_price));

			regTable = "target=\"_blank\" class=\"price\".*?data-btc=\".*?\">(.*?)</a></td>";
			String price=getInfo(info, regTable).replace("¥", "").replace(",", "").replace("亿", "");
			currencyModel.setPrice(MathUtil.doubleParse(price));

			regTable = "target=\"_blank\" class=\"price\".*?</a></td>.*?<td>(.*?)<";
			String Market_num=getInfo(info, regTable).replace("万", "").replace(",", "").replace("*", "");
			currencyModel.setMarket_num(MathUtil.longParse(Market_num));

			regTable = "class=\"volume\".*?>(.*?)</a></td>";
			currencyModel.setTurnover24h(getInfo(info, regTable));

			System.out.println("------------------------------------------");
			System.out.println(FastjsonUtils.jsonSerialize(currencyModel));
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return currencyModel;
	}

	private static String getInfo(String info, String regTable) {
		String reuslt = "";
		try {
			Pattern pattern = Pattern.compile(regTable);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt.trim();
	}

}
