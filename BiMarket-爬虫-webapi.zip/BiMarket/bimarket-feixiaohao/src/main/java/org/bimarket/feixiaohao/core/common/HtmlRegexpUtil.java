package org.bimarket.feixiaohao.core.common;

import java.util.regex.Matcher;  
import java.util.regex.Pattern;  
  
/** 
 * @ClassName: HtmlRegexpUtil 
 * @Description: 处理html标签 
 * @author YYYong 
 * @date 2016年5月18日 上午9:26:28 
 *  
 */  
public class HtmlRegexpUtil  
{  
  
    private final static String regxpForHtml = "<([^>]*)>"; // 过滤所有以<开头以>结尾的标签  
  
    private final static String rexImgTag = "<(img.*?)(class.*?)(src.*?)>";   // 找出IMG标签  
  
    private final static String regExpTag = "<(img.*?)(src.*?)(alt.*?)(title.*?)(height.*?)>"; // 找出表情标签  
  
    private final static String regATag = "(<(a.*?href=.*?)>(.*?)</a>)"; // 找出<a>标签  
      
    public final static String regSpanTag = "<(span.*?)(style.*?)>(.*?)</span>"; // 找出<span></span>标签  
      
    public final static String regStrongTag = "(<(a.*?href=.*?)>(.*?)</a>)"; // 找出<strong></strong>标签  
      
    private final static String spanTagPre = "<span style=\"text-decoration:underline;\">"; // 找出<span>标签  
      
    private final static String spanTagSuf = "</span>"; // 找出<span>标签  
      
    private final static String strongTagPre = "<strong>"; // 找出<strong>标签  
      
    private final static String strongTagSuf = "</strong>"; // 找出<strong>标签  
  
    /** 
     * @Title: handleImgTag 
     * @Description: 处理IMG标签 
     * @param @param str 
     * @param @param prefix 
     * @param @param suffix 
     * @param @return 设定文件 
     * @return String 返回类型 
     * @throws 
     */  
    public static String handleImgTag(String str, String prefix, String suffix)  
    {  
  
        Pattern pattern = Pattern.compile(rexImgTag);  
        Matcher matcher = pattern.matcher(str);  
        StringBuffer sb = new StringBuffer();  
        boolean result = matcher.find();  
        while (result)  
        {  
            String temp = matcher.group(3);  
            temp = temp.substring(6);  
            matcher.appendReplacement(sb, prefix + temp.substring(0, temp.length() - 1) + suffix);  
            result = matcher.find();  
        }  
        matcher.appendTail(sb);  
        return sb.toString();  
    }  
  
    /** 
     * @Title: handleExpTag 
     * @Description: 处理表情标签 
     * @param @param str 
     * @param @param prefix 
     * @param @param suffix 
     * @param @return 设定文件 
     * @return String 返回类型 
     * @throws 
     */  
    public static String handleExpTag(String str, String prefix, String suffix)  
    {  
  
        Pattern pattern = Pattern.compile(regExpTag);  
        Matcher matcher = pattern.matcher(str);  
        StringBuffer sb = new StringBuffer();  
        boolean result = matcher.find();  
        while (result)  
        {  
            String temp = matcher.group(4);  
            temp = temp.substring(7, temp.length() - 2);  
            matcher.appendReplacement(sb, prefix + temp + suffix);  
            result = matcher.find();  
        }  
        matcher.appendTail(sb);  
        return sb.toString();  
    }  
  
    /** 
    * @Title: handleATag 
    * @Description: 处理<a>标签 
    * @param @param str 
    * @param @param prefix 
    * @param @param suffix 
    * @param @return    设定文件 
    * @return String    返回类型 
    * @throws 
    */  
    public static String handleATag(String str, String prefix, String suffix)  
    {  
  
        Pattern pattern = Pattern.compile(regATag);  
        Matcher matcher = pattern.matcher(str);  
        StringBuffer sb = new StringBuffer();  
        boolean result = matcher.find();  
        while (result)  
        {  
            String temp = matcher.group(3);  
            if(temp.startsWith("$"))  
            {  
                // $符号为正则特殊符号，需替换后再处理  
                temp = "[@@]" + temp.substring(1, temp.length() - 1) + "[@@]";  
            }  
            matcher.appendReplacement(sb, prefix + temp + suffix);  
            result = matcher.find();  
        }  
        matcher.appendTail(sb);  
        return sb.toString().replace("[@@]", "$");  
    }  
  
    /** 
    * @Title: removeTag 
    * @Description: 移除标签 
    * @param @param str 
    * @param @param tag 
    * @param @return    设定文件 
    * @return String    返回类型 
    * @throws 
    */  
    public static String removeTag(String str,String tag)  
    {  
  
        int count = 2;  
        if(regSpanTag.equals(tag))  
        {  
            count++;  
        }  
        Pattern pattern = Pattern.compile(tag);  
        Matcher matcher = pattern.matcher(str);  
        StringBuffer sb = new StringBuffer();  
        boolean result = matcher.find();  
        while (result)  
        {  
            String temp = matcher.group(count);  
            matcher.appendReplacement(sb,temp);  
            result = matcher.find();  
        }  
        matcher.appendTail(sb);  
        if(count == 2)  
        {  
              
            return sb.toString().replace(strongTagPre, "").replace(strongTagSuf, "");  
        }  
        else  
        {  
  
            return sb.toString().replace(spanTagPre, "").replace(spanTagSuf, "");  
        }  
          
    }  
      
    /** 
     * @Title: replaceTag 
     * @Description: 替换标记以正常显示 
     * @param @param input 
     * @param @return 设定文件 
     * @return String 返回类型 
     * @throws 
     */  
    public String replaceTag(String input)  
    {  
        if(!hasSpecialChars(input))  
        {  
            return input;  
        }  
        StringBuffer filtered = new StringBuffer(input.length());  
        char c;  
        for (int i = 0; i <= input.length() - 1; i++)  
        {  
            c = input.charAt(i);  
            switch (c)  
            {  
                case '<':  
                    filtered.append("<");  
                    break;  
                case '>':  
                    filtered.append(">");  
                    break;  
                case '"':  
                    filtered.append("\""); 
                    break;  
                case '&':  
                    filtered.append("&");  
                    break;  
                default:  
                    filtered.append(c);  
            }  
  
        }  
        return (filtered.toString());  
    }  
  
    /** 
     * @Title: hasSpecialChars 
     * @Description: 判断标记是否存在 
     * @param @param input 
     * @param @return 设定文件 
     * @return boolean 返回类型 
     * @throws 
     */  
    public boolean hasSpecialChars(String input)  
    {  
        boolean flag = false;  
        if((input != null) && (input.length() > 0))  
        {  
            char c;  
            for (int i = 0; i <= input.length() - 1; i++)  
            {  
                c = input.charAt(i);  
                switch (c)  
                {  
                    case '>':  
                        flag = true;  
                        break;  
                    case '<':  
                        flag = true;  
                        break;  
                    case '"':  
                        flag = true;  
                        break;  
                    case '&':  
                        flag = true;  
                        break;  
                }  
            }  
        }  
        return flag;  
    }  
  
    /** 
     * @Title: filterHtml 
     * @Description: 基本功能：过滤所有以"<"开头以">"结尾的标签 
     * @param @param str 
     * @param @return 设定文件 
     * @return String 返回类型 
     * @throws 
     */  
    public static String filterHtml(String str)  
    {  
        Pattern pattern = Pattern.compile(regxpForHtml);  
        Matcher matcher = pattern.matcher(str);  
        StringBuffer sb = new StringBuffer();  
        boolean result1 = matcher.find();  
        while (result1)  
        {  
            matcher.appendReplacement(sb, "");  
            result1 = matcher.find();  
        }  
        matcher.appendTail(sb);  
        return sb.toString();  
    }  
  
    /** 
     * @Title: fiterHtmlTag 
     * @Description: 过滤指定标签 
     * @param @param str 
     * @param @param tag 
     * @param @return 设定文件 
     * @return String 返回类型 
     * @throws 
     */  
    public static String fiterHtmlTag(String str, String tag)  
    {  
        String regxp = "<\\s*" + tag + "\\s+([^>]*)\\s*>";  
        Pattern pattern = Pattern.compile(regxp);  
        Matcher matcher = pattern.matcher(str);  
        StringBuffer sb = new StringBuffer();  
        boolean result1 = matcher.find();  
        while (result1)  
        {  
            matcher.appendReplacement(sb, "");  
            result1 = matcher.find();  
        }  
        matcher.appendTail(sb);  
        return sb.toString();  
    }  
  
}  