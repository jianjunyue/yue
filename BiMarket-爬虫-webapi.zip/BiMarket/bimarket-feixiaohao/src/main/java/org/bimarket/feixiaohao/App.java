package org.bimarket.feixiaohao;

import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	HashMap hm =getHrefByNet("https://www.feixiaohao.com/list_1.html");

        System.out.println( hm );
        System.out.println( "Hello World!" );
    }
    
    public static HashMap getHrefByNet(String url)
    {    
      HashMap hm = new HashMap();
      String href = null;
         try {
            //这是get方式得到的
            Document doc = Jsoup.connect(url).get();
            String title = doc.title();
            Elements links = doc.select("table");
            
            for(Element link:links){
                
                String linkHref = link.attr("abs:href");
                String linkText = link.text();
                //System.out.println(linkText+":"+linkHref);
                hm.put(linkText, linkHref);
                href=linkText;
            } 
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            hm.put("加载失败", "error");
        }
         
        return hm ;
    }
    
    public static HashMap getHrefByNet1(String url)
    {    
      HashMap hm = new HashMap();
      String href = null;
         try {
            //这是get方式得到的
            Document doc = Jsoup.connect(url).get();
            String title = doc.title();
            Elements links = doc.select("a[href]");
            
            for(Element link:links){
                
                String linkHref = link.attr("abs:href");
                String linkText = link.text();
                //System.out.println(linkText+":"+linkHref);
                hm.put(linkText, linkHref);
                href=linkText;
            }
            //System.out.println("***************");
            //另外一种是post方式
            /*@SuppressWarnings("unused")
            Document doc_Post = Jsoup.connect(url)
                    .data("query","Java")
                    .userAgent("I am jsoup")
                    .cookie("auth","token")
                    .timeout(10000)
                    .post();
            Elements links_Post = doc.select("a[href]");
             for(Element link:links_Post){
                    String linkHref = link.attr("abs:href");
                    String linkText = link.text();
                    //System.out.println(linkText+":"+linkHref);
                    
                    //map.put(linkText, linkHref);
                }*/
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            hm.put("加载失败", "error");
        }
         
        return hm ;
    }
    
}
