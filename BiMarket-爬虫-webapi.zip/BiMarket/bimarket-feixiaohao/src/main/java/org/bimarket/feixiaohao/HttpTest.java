package org.bimarket.feixiaohao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.util.EntityUtils;
import org.bimarket.base.util.FileUtil;

public class HttpTest {

	public static void main(String[] args) {
		String url = "https://www.feixiaohao.com/list_1.html"; 
//		   FileUtil fileUtil =new FileUtil();
//		   String str=  fileUtil.read("/Users/jianjun.yue/git/BiMarket/bimarket-feixiaohao/src/main/java/org/bimarket/feixiaohao/test.txt");
//		   str=str.replace(" ", "").replace("\n", "").replace("\"", "").replace("\'", "");
//		   handleTable(str);
//		    test();
		ddd111(url);
//		ddd();
		

		System.out.println("end");
	}
	
	// <meta name="keywords" content="coinmarket,数字货币数据分析,数字货币行业大数据,虚拟币数据分析">
	// "<meta name=\"keywords\" content=\"(.*?)>";
	public static String handleTable(String str) {  
	 	   System.out.println(str.length() );
		String regTable =".*?<tr>(.*?)</tr>.*?";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		str=str.replace("\\n", "").replace("\n", "").replace("\\", "").replace("\\\\", "");
		Matcher matcher = pattern.matcher(str); 
		boolean find= matcher.find();
		if(matcher.matches()) {
			System.out.println("------------");
			reuslt = matcher.group(1);
			System.out.println(reuslt);
			handleTr(reuslt);
		}
		return reuslt;
	}

	public static void test() {
		String teString = "<trid=\"bitcoin\">asdsas</tr>";
		String str =" <tr>\n" + 
				"                                <th>#</th>\n" + 
				"                                <th data-sort-method='none'>名称</th>\n" + 
				"                                <th>流通市值</th>\n" + 
				"                                <th>价格</th>\n" + 
				"                                <th>流通数量</th>\n" + 
				"                                <th>成交额(24h)</th>\n" + 
				"                                <th>涨幅(24h)</th>\n" + 
				"                                                                    <th width=\"95\" data-sort-method='none'>价格趋势(7d)</th>\n" + 
				"                            </tr>\n" + 
				"" ;
//		str =" <tr> data-sort-method='none'>名称</tr><th>涨幅(24h)</th>\n";
		 handleTable(str) ;
//		handleTr(teString);
	}

	// <tr id="bitcoin">asdsas</tr>
	public static String handleTr(String str) {
		String regTable = "<trid=\".*?\">(.*?)</tr>";
		String reuslt = "";
		Pattern pattern = Pattern.compile(regTable);
		Matcher matcher = pattern.matcher(str);
		while (matcher.find()) {
			reuslt = matcher.group(1);
			System.out.println(reuslt);
		}
		return reuslt;
	}
	
	public static void ddd111(String url) {
		 //创建客户端
       CloseableHttpClient closeableHttpClient = HttpClients.createDefault();

       //创建请求Get实例
       HttpGet httpGet = new HttpGet(url);

       //设置头部信息进行模拟登录（添加登录后的Cookie）
       httpGet.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
       httpGet.setHeader("Accept-Encoding", "gzip, deflate, sdch, br");
       httpGet.setHeader("Accept-Language", "zh-CN,zh;q=0.8");
       //httpGet.setHeader("Cookie", ".......");
       httpGet.setHeader("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");

       try {
           //客户端执行httpGet方法，返回响应
           CloseableHttpResponse closeableHttpResponse = closeableHttpClient.execute(httpGet);

           //得到服务响应状态码
           if (closeableHttpResponse.getStatusLine().getStatusCode() == 200) {
        	   String strResult = EntityUtils.toString(closeableHttpResponse.getEntity());
        	   FileUtil fileUtil =new FileUtil();
        	   fileUtil.write("/Users/jianjun.yue/git/BiMarket/bimarket-feixiaohao/src/main/java/org/bimarket/feixiaohao/test.txt", strResult);
        	   System.out.println(strResult.length());
        	   handleTable(strResult);
               //打印所有响应头
               Header[] headers = closeableHttpResponse.getAllHeaders();
               for (Header header : headers) {
                   System.out.println(header.getName() + ": " + header.getValue());
               }
           }
           else {
               //如果是其他状态码则做其他处理
           }
       } catch (ClientProtocolException e) {
           e.printStackTrace();
       } catch (IOException e) {
           e.printStackTrace();
       } finally {
//           httpClient.close();
       }
   } 
	
	public static void ddd() {
		 //创建客户端
        CloseableHttpClient closeableHttpClient = HttpClients.createDefault();

        //创建请求Get实例
        HttpGet httpGet = new HttpGet("https://www.baidu.com");

        //设置头部信息进行模拟登录（添加登录后的Cookie）
        httpGet.setHeader("Accept", "text/html,application/xhtml+xml," +
                "application/xml;q=0.9,image/webp,*/*;q=0.8");
        httpGet.setHeader("Accept-Encoding", "gzip, deflate, sdch, br");
        httpGet.setHeader("Accept-Language", "zh-CN,zh;q=0.8");
        //httpGet.setHeader("Cookie", ".......");
        httpGet.setHeader("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" +
                " (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");

        try {
            //客户端执行httpGet方法，返回响应
            CloseableHttpResponse closeableHttpResponse = closeableHttpClient.execute(httpGet);

            //得到服务响应状态码
            if (closeableHttpResponse.getStatusLine().getStatusCode() == 200) {
                //打印所有响应头
                Header[] headers = closeableHttpResponse.getAllHeaders();
                for (Header header : headers) {
                    System.out.println(header.getName() + ": " + header.getValue());
                }
            }
            else {
                //如果是其他状态码则做其他处理
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
//            httpClient.close();
        }
    } 
	
	 public static String getContent(String url){
		 CloseableHttpClient httpClient = HttpClients.createDefault();
		 httpClient.getParams().setParameter(CoreProtocolPNames.USE_EXPECT_CONTINUE, false);
	        HttpUriRequest mRequest = new HttpGet(url);
	        mRequest.setHeader("Cache-control", "max-age=0");
	        mRequest.setHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
	        mRequest.setHeader("Accept-Charset","utf-8,GBK;q=0.7,*;q=0.3");
	        mRequest.setHeader("Accept-Encoding","identity;q=1.0,gzip;q=2.0");
	        mRequest.setHeader("Accept-Language","zh-CN,zh;q=0.8");
	        mRequest.setHeader("Connection","keep-alive");
	        mRequest.setHeader("Host","www.feixiaohao.com");
	        mRequest.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71 Safari/537.1 LBBROWSER");
	        HttpResponse mResponse;
	        try {
	            mResponse = httpClient.execute(mRequest);
//	          System.out.println(mResponse.getStatusLine());
	            if(mResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
	    			String strResult = EntityUtils.toString(mResponse.getEntity());
	                HttpEntity mEntity = mResponse.getEntity();

//	                String urlContent = getContentFromEntity(mEntity);
////	              System.out.println(urlContent);
//	                Pattern mPattern = Pattern.compile("<div class=\"con_mater\">(.*?</div>){6}</div>",Pattern.DOTALL);
//	                Matcher matcher = mPattern.matcher(urlContent);
//	                if(matcher.find()){
////	                  System.out.println(matcher.group());
//	                    StringBuilder sb = new StringBuilder();
//	                    String content = matcher.group();
//	                    sb.append("做法：").append(getState(content, "做法", true)).append("|")
//	                    .append("口味：").append(getState(content, "口味", true)).append("|")
//	                    .append("难度：").append(getState(content, "难度", true)).append("|")
//	                    .append("准备时间：").append(getState(content, "准备时间", false)).append("|")
//	                    .append("烹饪时间：").append(getState(content, "烹饪时间", true)).append("|")
//	                    .append("主料：").append(getMainMaterial(content)).append("|")
//	                    .append("辅料：").append(getAssistantMaterial(content)).append("\n");
//	                    return sb.toString();
//	                }else{
//	                    throw new Error("你被网站管理员发现了！！");
//	                }
	            }
	        } catch (ClientProtocolException e) {
	            throw new RuntimeException(e);
	        } catch (IOException e) {
	            throw new RuntimeException(e);
	        }
	         
	        return null;
	    }

}
