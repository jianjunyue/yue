package org.bimarket.feixiaohao.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bimarket.base.util.FastjsonUtils;
import org.bimarket.base.util.HttpClientHelper;
import org.bimarket.feixiaohao.core.model.CurrencyModel;
import org.bimarket.feixiaohao.data.CurrencyModelData;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

public class HomePageCore {
	private static final Logger logger = LoggerFactory.getLogger(HomePageCore.class);

	public static void main(String[] args) throws IOException {
		String url = "https://www.feixiaohao.com/currencies/ethereum/";
		CurrencyModel currencyModel = new CurrencyModel();
		currencyModel = getBiCurrencyModel(url, currencyModel);
		System.out.println("------------------------------------------");
		System.out.println(FastjsonUtils.jsonSerialize(currencyModel));
		System.out.println("Hello World!");
	}

	/**
	 * 获取所有货币列表
	 */
	public static CurrencyModel getBiCurrencyModel(String url, CurrencyModel currencyModel) {
		try {
			String info = HttpClientHelper.gethttpGet("https://www.feixiaohao.com" + url).replace("\r\n", "");

			String regTable = "<div class=\"cell maket\">.*?<img src=.*?>(.*?)<input type=\"hidden\"";
			currencyModel.setName(getInfo(info, regTable));

			regTable = "<input type=\"hidden\" id=\"coinname\" value=\".*?\">(.*?)</h1>";
			currencyModel.setName_cn(getInfo(info, regTable));

			regTable = "<div class=\"des\">.*?<a href=\"(.*?)/\"  target=\"_blank\">";
			String desUrl = getInfo(info, regTable);

			currencyModel.setDescribe(getDes(desUrl));
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return currencyModel;
	}

	private static String getDes(String desUrl) {
		String info = HttpClientHelper.gethttpGet("https://www.feixiaohao.com" + desUrl).replace("\r\n", "");

		String regTable = "<div class=\"boxContain\">.*?\">(.*?)</div>";
		return getInfo(info, regTable);
	}

	private static String getInfo(String info, String regTable) {
		String reuslt = "";
		try {
			Pattern pattern = Pattern.compile(regTable);
			Matcher matcher = pattern.matcher(info);
			while (matcher.find()) {
				reuslt = matcher.group(1);
			}
		} catch (Exception e) {
			logger.error("RestaurantInfoData getData is error", e);
		}
		return reuslt.trim();
	}

}
