package org.bimarket.feixiaohao.core.model;

public class CurrencyModel {
	
	private String name;// url 基础名称
	private String name_cn;//中文名称
	private String name_short;//简称
	public double getMarket_price() {
		return market_price;
	}
	public void setMarket_price(double market_price) {
		this.market_price = market_price;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Long getMarket_num() {
		return market_num;
	}
	public void setMarket_num(Long market_num) {
		this.market_num = market_num;
	}
	private double market_price;//流通市值
	private double price;//货币价格
	private Long market_num;//流通数量
	private String markey_rate;//流通率
	private String turnover24h;//24小时成交额
	private String rose1h;//涨幅(1h)
	private String rose24h;//涨幅(24h)
	private String rose7d;//涨幅(7d)
	private String high24h;//24h最高
	private String low24h;//24h最低
	private String describe;//介绍详情
	private String feixiaohao_currency_url;//非小号url
	private String priority;//展示优先级
	private String currency_logo;//币logo
	private String official_website;//货币官网 
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName_cn() {
		return name_cn;
	}
	public void setName_cn(String name_cn) {
		this.name_cn = name_cn;
	}
	public String getName_short() {
		return name_short;
	}
	public void setName_short(String name_short) {
		this.name_short = name_short;
	}
	public String getMarkey_rate() {
		return markey_rate;
	}
	public void setMarkey_rate(String markey_rate) {
		this.markey_rate = markey_rate;
	}
	public String getTurnover24h() {
		return turnover24h;
	}
	public void setTurnover24h(String turnover24h) {
		this.turnover24h = turnover24h;
	}
	public String getRose1h() {
		return rose1h;
	}
	public void setRose1h(String rose1h) {
		this.rose1h = rose1h;
	}
	public String getRose24h() {
		return rose24h;
	}
	public void setRose24h(String rose24h) {
		this.rose24h = rose24h;
	}
	public String getRose7d() {
		return rose7d;
	}
	public void setRose7d(String rose7d) {
		this.rose7d = rose7d;
	}
	public String getHigh24h() {
		return high24h;
	}
	public void setHigh24h(String high24h) {
		this.high24h = high24h;
	}
	public String getLow24h() {
		return low24h;
	}
	public void setLow24h(String low24h) {
		this.low24h = low24h;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getFeixiaohao_currency_url() {
		return feixiaohao_currency_url;
	}
	public void setFeixiaohao_currency_url(String feixiaohao_currency_url) {
		this.feixiaohao_currency_url = feixiaohao_currency_url;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getCurrency_logo() {
		return currency_logo;
	}
	public void setCurrency_logo(String currency_logo) {
		this.currency_logo = currency_logo;
	}
	public String getOfficial_website() {
		return official_website;
	}
	public void setOfficial_website(String official_website) {
		this.official_website = official_website;
	}
	

}
